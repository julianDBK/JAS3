import java.awt.Color;
import java.awt.Cursor;
import java.awt.Desktop;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;
import javax.swing.border.BevelBorder;
import javax.swing.plaf.DesktopIconUI;



public class MenuPrincipal extends JFrame {

    JLabel jImagen;
    JButton jbMate, jbHuma, jbFisi, jbAlg, jbSalir, jbUceva, jbTGS;
    JButton jbPag;

    public MenuPrincipal() {
        super("JAS");
        setSize(800, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(null);
        setResizable(false);
        Image icono = new ImageIcon(getClass().getResource("Imagenes/Logo.png")).getImage();
        setIconImage(icono);
        crearGUI();
        setVisible(true);
    }

    public void crearGUI() {
        ImageIcon imgOriginal = new ImageIcon(getClass().getResource("Imagenes/Menu.png"));
        ImageIcon imgEscalada = new ImageIcon(imgOriginal.getImage().getScaledInstance(800, 600, Image.SCALE_DEFAULT));
        jImagen = new JLabel(imgOriginal);
        jImagen.setBounds(0, 0, 800, 600);

        jbMate = new JButton("Matematicas");
        jbMate.setBounds(50, 20, 150, 40);
        jbMate.setToolTipText("Click Aqui");
        jbMate.setCursor(new Cursor(Cursor.HAND_CURSOR));
        jbMate.setOpaque(false);
        jbMate.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
        jbMate.setBorderPainted(true);
        jbMate.setBackground(Color.WHITE);
        jbMate.setFocusPainted(false);
        jbMate.setForeground(Color.WHITE);
        jbMate.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));

        jbMate.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                evento_jbMate();
            }
        });
        add(jbMate);

        jbFisi = new JButton("Fisica");
        jbFisi.setBounds(50, 100, 150, 40);
        jbFisi.setToolTipText("Click Aqui");
        jbFisi.setCursor(new Cursor(Cursor.HAND_CURSOR));
        jbFisi.setOpaque(false);
        jbFisi.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
        jbFisi.setBorderPainted(true);
        jbFisi.setBackground(Color.WHITE);
        jbFisi.setFocusPainted(false);
        jbFisi.setForeground(Color.WHITE);
        jbFisi.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
        jbFisi.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                evento_jbFisica();
            }
        });
        add(jbFisi);

        jbAlg = new JButton("TGS");
        jbAlg.setBounds(50, 200, 150, 40);
        jbAlg.setToolTipText("Click Aqui");
        jbAlg.setCursor(new Cursor(Cursor.HAND_CURSOR));
        jbAlg.setOpaque(false);
        jbAlg.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
        jbAlg.setBorderPainted(true);
        jbAlg.setBackground(Color.WHITE);
        jbAlg.setFocusPainted(false);
        jbAlg.setForeground(Color.WHITE);
        jbAlg.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
        jbAlg.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                eventoTGS();
            }
        });

        add(jbAlg);

        jbHuma = new JButton("Humanidades");
        jbHuma.setBounds(50, 300, 150, 40);
        jbHuma.setToolTipText("Click Aqui");
        jbHuma.setCursor(new Cursor(Cursor.HAND_CURSOR));
        jbHuma.setOpaque(false);
        jbHuma.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
        jbHuma.setBorderPainted(true);
        jbHuma.setBackground(Color.WHITE);
        jbHuma.setFocusPainted(false);
        jbHuma.setForeground(Color.WHITE);
        jbHuma.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
        jbHuma.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                evento_jbHuman();
            }
        });

        add(jbHuma);
        
        jbPag = new JButton("Pagina Web");
        jbPag.setBounds(50, 400, 150, 40);
        jbPag.setToolTipText("Click Aqui");
        jbPag.setCursor(new Cursor(Cursor.HAND_CURSOR));
        jbPag.setOpaque(false);
        jbPag.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
        jbPag.setBorderPainted(true);
        jbPag.setBackground(Color.WHITE);
        jbPag.setFocusPainted(false);
        jbPag.setForeground(Color.WHITE);
        jbPag.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));

        jbPag.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                gotoUrl("https://menujas.github.io/MenuJAS2/");
            }
        });
        
        add(jbPag);

        jbSalir = new JButton("Salir");
        jbSalir.setBounds(50, 490, 150, 40);
        jbSalir.setToolTipText("Click Aqui");
        jbSalir.setCursor(new Cursor(Cursor.HAND_CURSOR));
        jbSalir.setOpaque(false);
        jbSalir.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
        jbSalir.setBorderPainted(true);
        jbSalir.setBackground(Color.WHITE);
        jbSalir.setFocusPainted(false);
        jbSalir.setForeground(Color.WHITE);
        jbSalir.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
        jbSalir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                evento_salir();
            }
        });
        add(jbSalir);

        ImageIcon img = new ImageIcon(getClass().getResource("Imagenes/uceva.png"));
        ImageIcon imgEscalada1 = new ImageIcon(img.getImage().getScaledInstance(55, 55, Image.SCALE_DEFAULT));
        jbUceva = new JButton(imgEscalada1);
        jbUceva.setBounds(730, 505, 55, 55);
        jbUceva.setToolTipText("Click Aqui");
        jbUceva.setCursor(new Cursor(Cursor.HAND_CURSOR));
        jbUceva.setOpaque(false);
        jbUceva.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
        jbUceva.setBorderPainted(false);
        jbUceva.setBackground(Color.WHITE);
        jbUceva.setFocusPainted(false);
        jbUceva.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                evento_jbUceva();
            }
        });

        add(jbUceva);

        add(jImagen);
    }

    public void evento_jbHuman() {
        Humanidades hu = new Humanidades(this);
        setVisible(false);  // ocultar el menu principal

    }
    
        public void evento_jbMate() {
        Matematicas ma = new Matematicas(this);
        setVisible(false);  // ocultar el menu principal

    }
    
    public void evento_jbFisica(){
        Fisica eje = new Fisica(this);
        setVisible(false);
    }
    
    public void eventoTGS(){
        dispose();
        Tgs eje = new Tgs(this);
    }

    public void evento_salir() {
        int respuesta = JOptionPane.showConfirmDialog(this, "¿Desea salir de JAS?", "confirmacion", JOptionPane.YES_NO_OPTION);

        if (respuesta == JOptionPane.YES_OPTION) {
            System.exit(0);
        }
    }

    public void evento_jbUceva() {
        gotoUrl("https://www.uceva.edu.co");
    }

    public void gotoUrl(String url) {
        if (Desktop.isDesktopSupported()) {
            Desktop desktop = Desktop.getDesktop();

            if (desktop.isSupported(Desktop.Action.BROWSE)) {
                try {
                    URI uri = new URI(url);
                    desktop.browse(uri);
                } catch (URISyntaxException | IOException ex) {
                    JOptionPane.showMessageDialog(this, "Error al abrir la pagina " + url, "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }

    }
}