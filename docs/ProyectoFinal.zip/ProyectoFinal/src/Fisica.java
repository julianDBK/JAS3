
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Desktop;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;
import javax.swing.border.BevelBorder;

public class Fisica extends JFrame {

    MenuPrincipal mp;
    JButton jbMini;
    JButton jbVolver, video;
    JLabel jlTextoimg, titulo, mensaje, mensaje2;
    JTextArea contenido;
    JScrollPane js;
    
    

    public Fisica(MenuPrincipal obj) {
        super("FISICA");
        mp = obj;
        setSize(800, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
        getContentPane().setBackground(Color.BLACK);
        Image icono = new ImageIcon(getClass().getResource("Imagenes/Logo.png")).getImage();
        setIconImage(icono);
        setLayout(null);
        crearGUI();
        setVisible(true);

    }

    Fisica() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void crearGUI() {
        
        titulo = new JLabel("FISICA II");
        titulo.setBounds(300, 5, 600, 100);
        titulo.setBackground(Color.red);
        titulo.setForeground(Color.WHITE);
        titulo.setFont(new Font("Times new Roman", Font.BOLD, 24));
        add(titulo);
        
        contenido = new JTextArea();
        contenido.setFont(new Font("Times new Roman", Font.BOLD, 20));
        contenido.setText("La contaminación electromagnética es un tipo de contaminación ambiental causada por campos de fuentes artificiales, como líneas eléctricas, torres de transmisión de radio y televisión, antenas de telecomunicaciones y dispositivos electrónicos. La combinación de ondas eléctricas y magnéticas que se propagan a través del espacio generan efectos negativos en el medio ambiente y los seres vivos." + 
                "\n\nLos dispositivos electrónicos tanto domésticos como de uso personal pueden afectar de manera significativa la salud humana, causando síntomas como, dolores de cabeza, fatiga, trastornos de sueño y problemas de concentración.\n\n"+
                " Según estudios realizados la contaminación electromagnética puede llegar aumentar el riesgo de enfermedades severas como el cáncer y transtornos  neurologicos.");
        contenido.setWrapStyleWord(true);
        contenido.setBackground(Color.BLACK);
        contenido.setForeground(Color.white);
        contenido.setLineWrap(true);
        contenido.setEditable(false);
        
        js = new JScrollPane(contenido);
        js.setBounds(400, 100, 350, 350);
        
        add(js);
        
        ImageIcon yt = new ImageIcon(getClass().getClassLoader().getResource("Imagenes/youtube.png")); 
        ImageIcon ytS = new ImageIcon(yt.getImage().getScaledInstance(120, 100, Image.SCALE_DEFAULT));
        video = new JButton(ytS);
        video.setBounds(20, 350, 120, 100);
        video.setOpaque(false);
        video.setToolTipText("Video Informativo");
        video.setCursor(new Cursor(Cursor.HAND_CURSOR));
        video.setBackground(Color.white);
        video.setBorder(null);
        video.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                eventoVideo();
            }
        });
        add(video);
        
        
        mensaje = new JLabel("Video Informativo");
        mensaje.setBounds(130, 380, 200, 50);
        mensaje.setForeground(Color.white);
        mensaje.setFont(new Font("Times new Roman", Font.BOLD, 24));
        add(mensaje);
        
        mensaje2 = new JLabel("El unico responsable del avance ambiental eres tu ¡Animo!");
        mensaje2.setBounds(80, 450, 650, 50);
        mensaje2.setForeground(Color.white);
        mensaje2.setFont(new Font("Times new Roman", Font.BOLD, 24));
        add(mensaje2);
        
       

        ImageIcon logo = new ImageIcon(getClass().getResource("Imagenes/Fisica.jpg"));
        ImageIcon imgEscalada1 = new ImageIcon(logo.getImage().getScaledInstance(350, 250, Image.SCALE_DEFAULT));
        jlTextoimg = new JLabel(imgEscalada1);
        jlTextoimg.setBounds(30, 100, 350, 250);
        add(jlTextoimg);

        jbVolver = new JButton("Volver");
        jbVolver.setBounds(30, 505, 150, 40);
        jbVolver.setToolTipText("Click Aqui");
        jbVolver.setCursor(new Cursor(Cursor.HAND_CURSOR));
        jbVolver.setOpaque(false);
        jbVolver.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
        jbVolver.setBorderPainted(true);
        jbVolver.setOpaque(false);
        jbVolver.setBackground(Color.WHITE);
        jbVolver.setFocusPainted(false);
        jbVolver.setForeground(Color.WHITE);
        jbVolver.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                evento_jbVolver();
            }
        });
        add(jbVolver);

        jbMini = new JButton("Trivia");
        jbMini.setBounds(660, 505, 100, 40);
        jbMini.setToolTipText("Click Aqui");
        jbMini.setCursor(new Cursor(Cursor.HAND_CURSOR));
        jbMini.setOpaque(false);
        jbMini.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
        jbMini.setBorderPainted(true);
        jbMini.setOpaque(false);
        jbMini.setBackground(Color.WHITE);
        jbMini.setFocusPainted(false);
        jbMini.setForeground(Color.WHITE);
        jbMini.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                 evento_Minijuego();
            }
        });
        add(jbMini);

       

    }
    public void eventoVideo(){
        gotoUrl("https://www.youtube.com/watch?v=16ZRE981nJ0");
    }

    public void gotoUrl(String url){
        if (Desktop.isDesktopSupported()) {
            Desktop desktop = Desktop.getDesktop();

            if (desktop.isSupported(Desktop.Action.BROWSE)) {
                try {
                    URI uri = new URI(url);
                    desktop.browse(uri);
                } catch (URISyntaxException | IOException ex) {
                    JOptionPane.showMessageDialog(this, "Error al abrir la pagina " + url, "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }

    public void evento_jbVolver() {
        setVisible(false);
        dispose();
        mp.setVisible(true);

    }
    
    public void evento_Minijuego(){
        fisica2 eje = new fisica2();
        setVisible(false);
    }

}
