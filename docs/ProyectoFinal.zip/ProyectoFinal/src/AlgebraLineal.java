

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;
import javax.swing.border.BevelBorder;

public class AlgebraLineal extends JFrame {

    JButton jbVolver, jbSiguiente;
    JLabel jlTexto, jlImagen;
    MenuPrincipal mp;
    JTextArea jtSuma, jtPrVectoria, jtDesc, jtPrEsc, jtPrMix, jtEsc, jtEs;
    Color fondo = new Color(231,75,50 );

    public AlgebraLineal(MenuPrincipal obj) {
        super("Algebra Lineal");
        mp = obj;
        setSize(800, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
        getContentPane().setBackground(Color.BLACK);
        Image icono = new ImageIcon(getClass().getResource("Imagenes/Logo.png")).getImage();
        setIconImage(icono);
        setLayout(null);
        //addMouseListener(this);
        crearGUI();
        setVisible(true);
    }

    public void crearGUI() {
        jbVolver = new JButton("Volver");
        jbVolver.setBounds(30, 505, 150, 40);
        jbVolver.setToolTipText("Click Aqui");
        jbVolver.setCursor(new Cursor(Cursor.HAND_CURSOR));
        jbVolver.setOpaque(false);
        jbVolver.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
        jbVolver.setBorderPainted(true);
        jbVolver.setOpaque(false);
        jbVolver.setBackground(Color.WHITE);
        jbVolver.setFocusPainted(false);
        jbVolver.setForeground(Color.WHITE);
        jbVolver.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                evento_jbVolver();
            }
        });
        add(jbVolver);

        jbSiguiente = new JButton("Calculadora de Vectores");
        jbSiguiente.setBounds(604, 505, 150, 40);
        jbSiguiente.setToolTipText("Click Aqui");
        jbSiguiente.setCursor(new Cursor(Cursor.HAND_CURSOR));
        jbSiguiente.setOpaque(false);
        jbSiguiente.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
        jbSiguiente.setBorderPainted(true);
        jbSiguiente.setOpaque(false);
        jbSiguiente.setBackground(Color.WHITE);
        jbSiguiente.setFocusPainted(false);
        jbSiguiente.setForeground(Color.WHITE);
        jbSiguiente.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                evento_jbCalcv();
            }
        });
        add(jbSiguiente);

        jlTexto = new JLabel("VECTORES");
        jlTexto.setBounds(0, -10, 800, 80);
        jlTexto.setOpaque(false);
        jlTexto.setBackground(Color.BLACK);
        jlTexto.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 30));
        jlTexto.setForeground(Color.WHITE);
        jlTexto.setHorizontalAlignment(SwingConstants.CENTER);
        add(jlTexto);

        ImageIcon logo = new ImageIcon(getClass().getResource("Imagenes/Algebra.jpg"));
        ImageIcon imgEscalada2 = new ImageIcon(logo.getImage().getScaledInstance(800, 600, Image.SCALE_DEFAULT));
        jlImagen = new JLabel(imgEscalada2);
        jlImagen.setBounds(0, 0, 800, 600);


        jtEs = new JTextArea("VECTORES:                                                                                                                             Son un segmento de recta, contado a partir de un punto del espacio, cuya longitud representa a escala una magnitud, en una dirección determinada y en uno de sus sentidos.");
        jtEs.setWrapStyleWord(true);
        jtEs.setLineWrap(true);
        jtEs.setBounds(30, 60, 740, 100);
        jtEs.setOpaque(true);
        jtEs.setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED));
        jtEs.setFont(new Font("Times New Roman", Font.BOLD, 20));
        jtEs.setOpaque(false);
        jtEs.setForeground(Color.WHITE);
        jtEs.setEnabled(true);
        jtEs.setEditable(false);

        add(jtEs);

        jtSuma = new JTextArea("                    SUMA                 Es formar una cadena de vectores donde el vector que engloba a todos los vectores es el vector de la suma, se realiza con la propiedad conmutativa.");
        jtSuma.setWrapStyleWord(true);
        jtSuma.setLineWrap(true);
        jtSuma.setBounds(30, 180, 200, 140);
        jtSuma.setOpaque(true);
        jtSuma.setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED));
        jtSuma.setFont(new Font("Tahoma", Font.BOLD, 15));
        jtSuma.setOpaque(false);
        jtSuma.setForeground(Color.WHITE);
        jtSuma.setEnabled(true);
        jtSuma.setEditable(false);

        add(jtSuma);

        jtPrEsc = new JTextArea("     PRODUCTO POR UN                      ESCALAR                 Es la multiplicación de sus módulos por el coseno del ángulo que forman ambos vectores.");
        jtPrEsc.setWrapStyleWord(true);
        jtPrEsc.setLineWrap(true);
        jtPrEsc.setBounds(300, 180, 200, 140);
        jtPrEsc.setOpaque(true);
        jtPrEsc.setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED));
        jtPrEsc.setFont(new Font("Tahoma", Font.BOLD, 15));
        jtPrEsc.setOpaque(false);
        jtPrEsc.setForeground(Color.WHITE);
        jtPrEsc.setEnabled(true);
        jtPrEsc.setEditable(false);

        add(jtPrEsc);

        jtEsc = new JTextArea("    PRODUCTO ESCALAR   Es una operación algebraica que toma dos vectores y retorna un escalar (numero), y que satisface ciertas condiciones.");
        jtEsc.setWrapStyleWord(true);
        jtEsc.setLineWrap(true);
        jtEsc.setBounds(570, 180, 200, 140);
        jtEsc.setOpaque(true);
        jtEsc.setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED));
        jtEsc.setFont(new Font("Tahoma", Font.BOLD, 15));
        jtEsc.setOpaque(false);
        jtEsc.setForeground(Color.WHITE);
        jtEsc.setEnabled(true);
        jtEsc.setEditable(false);

        add(jtEsc);

        jtPrVectoria = new JTextArea("  PRODUCTO VECTORIAL Es una operación binaria entre dos vectores en un espacio tridimensional. El resultado es un vector perpendicular a los vectores que se multiplican");
        jtPrVectoria.setWrapStyleWord(true);
        jtPrVectoria.setLineWrap(true);
        jtPrVectoria.setBounds(30, 330, 200, 160);
        jtPrVectoria.setOpaque(true);
        jtPrVectoria.setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED));
        jtPrVectoria.setFont(new Font("Tahoma", Font.BOLD, 15));
        jtPrVectoria.setOpaque(false);
        jtPrVectoria.setForeground(Color.WHITE);
        jtPrVectoria.setEnabled(true);
        jtPrVectoria.setEditable(false);

        add(jtPrVectoria);

        jtPrMix = new JTextArea("       PRODUCTO MIXTO     Es una operación entre tres vectores que combina el producto escalar con el producto vectorial para obtener de resultado un escalar.");
        jtPrMix.setWrapStyleWord(true);
        jtPrMix.setLineWrap(true);
        jtPrMix.setBounds(300, 330, 200, 160);
        jtPrMix.setOpaque(true);
        jtPrMix.setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED));
        jtPrMix.setFont(new Font("Tahoma", Font.BOLD, 15));
        jtPrMix.setOpaque(false);
        jtPrMix.setForeground(Color.WHITE);
        jtPrMix.setEnabled(true);
        jtPrMix.setEditable(false);

        add(jtPrMix);

        jtDesc = new JTextArea("   DESCOMPOSICION DE                 UN VECTOR          Es obtener las componentes de un vector. Es decir, la proyección sobre los ejes del plano cartesiano X,Y,Z, del vector original.");
        jtDesc.setWrapStyleWord(true);
        jtDesc.setLineWrap(true);
        jtDesc.setBounds(570, 330, 200, 160);
        jtDesc.setOpaque(true);
        jtDesc.setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED));
        jtDesc.setFont(new Font("Tahoma", Font.BOLD, 15));
        jtDesc.setOpaque(false);
        jtDesc.setForeground(Color.WHITE);
        jtDesc.setEnabled(true);
        jtDesc.setEditable(false);

        add(jtDesc);

        add(jlImagen);
    }
    
        public void evento_jbCalcv() {
       
        CalcVectores cv = new CalcVectores(this);
        setVisible(false);
    }

    public void evento_jbVolver() {
        setVisible(false);
        dispose();
        mp.setVisible(true);
    }

}
