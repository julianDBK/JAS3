
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class envioCorreo extends JFrame {

    JLabel lNom, lCodigo, lCorreo, lNota, lIntentos;
    JTextField tNom, tCodigo, tCorreo, tNota;

    JButton bBuscar, bEnviar;

    Font eti = new Font("Times new Roman", Font.BOLD, 25);

    FileReader leer;
    FileWriter archivo;

    double notaFinal;
    String nota, intentos, mensaje = "";

    boolean ready = false;

    public envioCorreo(double not, double cant) {
        super("Envio de Correo");

        notaFinal = not / cant;
        intentos = String.valueOf(cant);
        nota = String.valueOf(notaFinal);
        setSize(600, 600);
        setResizable(false);
        setLocationRelativeTo(null);
        setLayout(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        crearGUI();

        setVisible(true);
    }

    public void crearGUI() {

        //------------------------------ Label
        lNom = new JLabel("Nombre");
        lNom.setBounds(150, 40, 150, 40);
        lNom.setFont(eti);
        add(lNom);

        lCodigo = new JLabel("Codigo");
        lCodigo.setBounds(150, 120, 150, 40);
        lCodigo.setFont(eti);
        add(lCodigo);

        lCorreo = new JLabel("Correo");
        lCorreo.setBounds(150, 200, 150, 40);
        lCorreo.setFont(eti);
        add(lCorreo);

        lNota = new JLabel("Nota");
        lNota.setBounds(150, 280, 150, 40);
        lNota.setFont(eti);
        add(lNota);

        lIntentos = new JLabel("Intentos = " + intentos);
        lIntentos.setFont(eti);
        lIntentos.setBounds(200, 350, 200, 60);
        add(lIntentos);

        //------------------------------------ TField
        tNom = new JTextField();
        tNom.setEditable(false);
        tNom.setBounds(260, 45, 200, 30);
        add(tNom);

        tCodigo = new JTextField();
        tCodigo.setBounds(260, 125, 200, 30);
        add(tCodigo);

        tCorreo = new JTextField();
        tCorreo.setBounds(260, 205, 200, 30);
        add(tCorreo);

        tNota = new JTextField();
        tNota.setText(nota);
        tNota.setEditable(false);
        tNota.setBounds(260, 285, 200, 30);
        add(tNota);

        //-------------------------------- jButtom
        bBuscar = new JButton("Buscar");
        bBuscar.setBounds(225, 450, 150, 60);
        bBuscar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                validacionBase();
            }
        });
        add(bBuscar);

        bEnviar = new JButton("Enviar");
        bEnviar.setBounds(400, 450, 150, 60);
        bEnviar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                eventoEnviar();
            }
        });
        add(bEnviar);

    }

    //---------------------------------------------- Base de Datos
    public void validacionBase() {
        boolean veri = false, error = false;
        int max = 0;

        try {
            leer = new FileReader("usuarios.csv");
        } catch (IOException e) {
            error = true;
            JOptionPane.showMessageDialog(null, "Error");
        }

        if (!error) {
            BufferedReader read = new BufferedReader(leer);
            String registro;
            String tokens[] = new String[2];

            try {
                while ((registro = read.readLine()) != null) {
                    tokens = registro.split(";");
                    for (int i = 0; i < tokens.length; i++) {
                        System.out.println(i + ". token = " + tokens[i]);

                        if (tokens[i].equals(tCodigo.getText())) {
                            veri = true;
                            tNom.setText(tokens[i - 1]);
                            tCodigo.setEditable(false);
                            ready = true;
                        }

                    }
                }
            } catch (IOException e) {
            }
            if (!veri) {
                JOptionPane.showMessageDialog(null, "Codigo no encontrado");
            }

            try {
                leer.close();
            } catch (IOException e) {
            }

        }

    }

    public void eventoEnviar() {
        if (ready) {
            mensaje = "Nombre = " + tNom.getText() + "<br><br>Codigo = " + tCodigo.getText() + "<br>Correo = " + tCorreo.getText() + "<br>Cant intentos = " + intentos + "<br>Nota = " + nota;
            System.out.println(mensaje);
            generarCorreo eje = new generarCorreo();
            eje.test1(mensaje);
            try {
                escribirArchivo();
            } catch (IOException ex) {
                Logger.getLogger(envioCorreo.class.getName()).log(Level.SEVERE, null, ex);
            }
        }else{
            JOptionPane.showMessageDialog(null, "Falta Nombre");
        }
    }
    
    public void escribirArchivo() throws IOException{
        boolean error= false;
        try {
            archivo = new FileWriter("respuestasCuestionario.csv", true);
        } catch (IOException e) {
            error= true;
            JOptionPane.showMessageDialog(null, "error = "+ e);
        }   
        if(!error){
            
            archivo.write(tNom.getText()+";"+tCodigo.getText()+ ";" + tCorreo.getText() + ";" + intentos + ";" + nota + "\r\n");//Hola
            
        }
        try {
            archivo.close();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error al cerrar el archivo");
        }
    }

    // QUE DEBE ENVIAR = Nombre - Codigo - Correo - Intento - Nota(Promedio)
}
