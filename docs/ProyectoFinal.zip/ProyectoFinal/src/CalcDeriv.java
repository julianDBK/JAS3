
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import javax.swing.*;
import javax.swing.border.BevelBorder;
import javax.swing.border.Border;

/**
 *
 * @author julian
 */
public class CalcDeriv extends JFrame{
    
    JButton derivar;
    JButton jbVolver;
    JButton video;
    JButton clean;
    JLabel derivada1;
    JLabel derivada2;
    JLabel mensaje;
    JTextField funcionE;
    JTextField funcionS;
    Font mifuente = new Font("Calibri", Font.BOLD, 24) {};
    Font mifuente2 = new Font("Calibri", Font.BOLD, 19) {};
    Matematicas mt;
    
    public CalcDeriv(Matematicas obj){
        mt = obj;
        setSize(800, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
        //Image retvalue = Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource("img/jas.png"));
        //setIconImage(retvalue);
        setLayout(null);
        getContentPane().setBackground(Color.BLACK);
        setVisible(true);
        
        Derivada();
        
    }
    
    public void Derivada() {

        // Funcion a derivar
        derivada1 = new JLabel();
        derivada1.setText("Funcion a derivar");
        derivada1.setBounds(269, 50, 200, 100);
        
        derivada1.setFont(mifuente);
        derivada1.setForeground(Color.WHITE);
        add(derivada1);

        funcionE = new JTextField();
        funcionE.setBounds(180, 130, 350, 40);
        funcionE.setFont(mifuente2);
        add(funcionE);

        // Boton derivar
        derivar = new JButton("Derivar");
        derivar.setBounds(550, 135, 100, 30);
        add(derivar);
        derivar.setVisible(true);
        botonDerivar();

        // Boton clean
        clean = new JButton("Clean");
        clean.setBounds(550, 345, 100, 30);
        add(clean);
        botonClean();

        // Funcion derivada
        derivada2 = new JLabel();
        derivada2.setText("Funcion derivada");
        derivada2.setBounds(269, 250, 200, 100);
        derivada2.setForeground(Color.WHITE);
        derivada2.setFont(mifuente);
        add(derivada2);

        funcionS = new JTextField();
        funcionS.setBounds(180, 340, 350, 40);
        funcionS.setFont(mifuente2);
        add(funcionS);
        
        jbVolver = new JButton("Volver");
        jbVolver.setBounds(30, 505, 150, 40);
        jbVolver.setToolTipText("Click Aqui");
        jbVolver.setCursor(new Cursor(Cursor.HAND_CURSOR));
        jbVolver.setOpaque(false);
        jbVolver.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
        jbVolver.setBorderPainted(true);
        jbVolver.setOpaque(true);
        jbVolver.setBackground(Color.WHITE);
        jbVolver.setFocusPainted(false);
        jbVolver.setForeground(Color.BLACK);
        jbVolver.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                evento_jbVolver();
            }
        });
        add(jbVolver);
        
        mensaje = new JLabel("Curso ProfeAlex : ");
        mensaje.setBounds(520, 500, 200, 50);
        mensaje.setFont(mifuente);
        add(mensaje);
        
        ImageIcon yt = new ImageIcon(getClass().getClassLoader().getResource("Imagenes/youtube.png")); 
        ImageIcon ytS = new ImageIcon(yt.getImage().getScaledInstance(80, 60, Image.SCALE_DEFAULT));
        video = new JButton(ytS);
        video.setBounds(700, 495, 80, 60);
        video.setOpaque(false);
        video.setToolTipText("Videos derivadas");
        video.setCursor(new Cursor(Cursor.HAND_CURSOR));
        video.setBackground(Color.white);
        video.setBorder(null);
        video.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                eventoVideo();
            }
        });
        add(video);
    }
    
    public void evento_jbVolver(){
        setVisible(false);
        dispose();
        mt.setVisible(true);
    }
    
    public void eventoVideo(){
        gotoUrl("https://www.youtube.com/playlist?list=PLeySRPnY35dG2UQ35tPsaVMYkQhc8Vp__");
    }
    
    public void gotoUrl(String url){
        if (Desktop.isDesktopSupported()) {
            Desktop desktop = Desktop.getDesktop();

            if (desktop.isSupported(Desktop.Action.BROWSE)) {
                try {
                    URI uri = new URI(url);
                    desktop.browse(uri);
                } catch (URISyntaxException | IOException ex) {
                    JOptionPane.showMessageDialog(this, "Error al abrir la pagina " + url, "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }
    
    private void botonDerivar() {
        derivar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String funcion = funcionE.getText();

                Derivada derivada = new Derivada();

                derivada.setFuncionADerivar(funcion);
                derivada.derivar();

                funcionS.setText(derivada.getFuncionDerivada());
                System.out.println(derivada.getFuncionDerivada());
            }
        });

    }
    
     private void botonClean() {
        clean.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                funcionE.setText("");
                funcionS.setText("");
            }
        });
    }
}
