
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Desktop;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;
import javax.swing.border.BevelBorder;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Usuario
 */
public class Tgs extends JFrame{

    JButton jbVolver, jbJuego, video;
    JLabel jlTextoimg, titulo, mensaje, mensaje2;
    JTextArea contenido;
    JScrollPane js;
    MenuPrincipal mp;

    ArrayList<Estudiante> guardar = new ArrayList<>();
    
    FileReader leer;
    BufferedReader read;

    int pos, cont = 0;
    Integer [] notas;
    double[] num;

    public Tgs(MenuPrincipal obj) {
        super("TEORIA GENERAL DE SISTEMAS");
        mp = obj;
        setSize(800, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
        getContentPane().setBackground(Color.BLACK);
        Image icono = new ImageIcon(getClass().getResource("Imagenes/Logo.png")).getImage();
        setIconImage(icono);
        setLayout(null);
        crearGUI();
        setVisible(true);
    }

    public void crearGUI() {
        
        titulo = new JLabel("Teoria General de Sistemas");
        titulo.setBounds(300, 5, 600, 100);
        titulo.setBackground(Color.red);
        titulo.setForeground(Color.WHITE);
        titulo.setFont(new Font("Times new Roman", Font.BOLD, 24));
        add(titulo);
        
        contenido = new JTextArea();
        contenido.setFont(new Font("Times new Roman", Font.BOLD, 20));
        contenido.setText("Las acciones verdes sostenibles incluyen iniciativas y prácticas que promueven la protección del medio ambiente"+
                "y la utilización de los recursos naturales de manera responsable y sostenible, mientras se fomenta un crecimiento económico"+
                "inclusivo.\n\n Algunas de estas acciones incluyen el uso de energías renovables, la reducción de emisiones de gases de efecto"+
                "invernadero, la promoción de la eficiencia energética, el fomento del transporte público y la movilidad sostenible, la gestión"+
                "y el uso responsable del agua, la implementación de prácticas de producción sostenible y la conservación de la biodiversidad y "+
                "los ecosistemas terrestres y marinos. Además, existen programas y proyectos gubernamentales y no gubernamentales que promueven "+
                "estas prácticas, como el Programa Nacional de Pagos Por Servicios Ambientales y los Bonos Verdes.\n\n"+
                "Algunas de las acciones verdes sostenibles más importantes incluyen:\n"+
                "\n1. El uso de energías renovables: la implementación de fuentes de energía limpia, como la solar, la eólica y la hidroeléctrica, ayuda a reducir la dependencia de combustibles fósiles y disminuye las emisiones de gases de efecto invernadero.\n"+
                "\n2. La promoción de la eficiencia energética: fomentar prácticas y tecnologías que permitan el uso eficiente de la energía, como el uso de iluminación LED y de electrodomésticos de bajo consumo, ayuda a disminuir el consumo de energía eléctrica y, por ende, su impacto ambiental.\n"+
                "\n3. La gestión y el uso responsable del agua: el agua es un recurso natural indispensable, por lo que es importante utilizarla de manera responsable y promover prácticas de conservación y reutilización.");
        contenido.setWrapStyleWord(true);
        contenido.setBackground(Color.BLACK);
        contenido.setForeground(Color.white);
        contenido.setLineWrap(true);
        contenido.setEditable(false);
        
        js = new JScrollPane(contenido);
        js.setBounds(400, 100, 350, 350);
        
        add(js);
        
        ImageIcon yt = new ImageIcon(getClass().getClassLoader().getResource("Imagenes/youtube.png")); 
        ImageIcon ytS = new ImageIcon(yt.getImage().getScaledInstance(120, 100, Image.SCALE_DEFAULT));
        video = new JButton(ytS);
        video.setBounds(20, 350, 120, 100);
        video.setOpaque(false);
        video.setToolTipText("Video Informativo");
        video.setCursor(new Cursor(Cursor.HAND_CURSOR));
        video.setBackground(Color.white);
        video.setBorder(null);
        video.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                eventoVideo();
            }
        });
        add(video);
        
        
        mensaje = new JLabel("Video Informativo");
        mensaje.setBounds(130, 380, 200, 50);
        mensaje.setForeground(Color.white);
        mensaje.setFont(new Font("Times new Roman", Font.BOLD, 24));
        add(mensaje);
        
        mensaje2 = new JLabel("El unico responsable del avance ambiental eres tu ¡Animo!");
        mensaje2.setBounds(80, 450, 650, 50);
        mensaje2.setForeground(Color.white);
        mensaje2.setFont(new Font("Times new Roman", Font.BOLD, 24));
        add(mensaje2);
        
        jbVolver = new JButton("Volver");
        jbVolver.setBounds(30, 505, 150, 40);
        jbVolver.setToolTipText("Click Aqui");
        jbVolver.setCursor(new Cursor(Cursor.HAND_CURSOR));
        jbVolver.setOpaque(false);
        jbVolver.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
        jbVolver.setBorderPainted(true);
        jbVolver.setBackground(Color.WHITE);
        jbVolver.setFocusPainted(false);
        jbVolver.setForeground(Color.WHITE);
        jbVolver.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                evento_jbVolver();
            }
        });
        add(jbVolver);

        jbJuego = new JButton("Juego");
        jbJuego.setBounds(604, 505, 150, 40);
        jbJuego.setToolTipText("Realizar cuestionario");
        jbJuego.setCursor(new Cursor(Cursor.HAND_CURSOR));
        jbJuego.setOpaque(false);
        jbJuego.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
        jbJuego.setBorderPainted(true);
        jbJuego.setBackground(Color.WHITE);
        jbJuego.setFocusPainted(false);
        jbJuego.setForeground(Color.WHITE);
        jbJuego.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //evento_jbJuego();
            }
        });
        add(jbJuego);

        ImageIcon logo = new ImageIcon(getClass().getResource("Imagenes/Tgs.jpg"));
        ImageIcon imgEscalada1 = new ImageIcon(logo.getImage().getScaledInstance(350, 250, Image.SCALE_DEFAULT));
        jlTextoimg = new JLabel(imgEscalada1);
        jlTextoimg.setBounds(30, 100, 350, 250);
        add(jlTextoimg);

    }

    public void eventoVideo(){
        gotoUrl("https://www.youtube.com/watch?v=WpHYtwt1R_E");
    }

    public void gotoUrl(String url){
        if (Desktop.isDesktopSupported()) {
            Desktop desktop = Desktop.getDesktop();

            if (desktop.isSupported(Desktop.Action.BROWSE)) {
                try {
                    URI uri = new URI(url);
                    desktop.browse(uri);
                } catch (URISyntaxException | IOException ex) {
                    JOptionPane.showMessageDialog(this, "Error al abrir la pagina " + url, "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }
    
    
    public void evento_jbVolver() {
        setVisible(false);
        dispose();
        mp.setVisible(true);

    }
}
