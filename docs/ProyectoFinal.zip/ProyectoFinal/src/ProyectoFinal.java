import javax.swing.*;
import java.awt.*;
import static java.awt.Frame.MAXIMIZED_VERT;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.LimitExceededException;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

public class ProyectoFinal extends JFrame{

    JPanel panel1;
    JLabel logo;
    JLabel usuario;
    JLabel contraseña;
    JButton salir;
    JButton ingresar;
    JButton registrar;
    
    JTextField usuarioE;
    JTextField codigoE;
    Font ingreso = new Font("Calibri", Font.BOLD, 20) {};
    Font ingresoboton = new Font("Calibri", Font.BOLD, 6) {};
    FileWriter archivo = null;
    FileReader leer = null;
    
    Datos dt = new Datos();
    //ArrayList<Datos> dato = new ArrayList<>();
    
    int cant = 0;
    
    public ProyectoFinal(){
        setBounds(0, 0, 500, 580);
        setTitle("JAS");
        setLayout(null);
        setLocationRelativeTo(null);
        setUndecorated(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
        //Image retvalue = Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource("img/jas.png"));
        //setIconImage(retvalue);
        
        setVisible(true);
        panelPrincipal();
        
    }
    
    public void panelPrincipal(){
        panel1 = new JPanel();
        panel1.setBounds(0, 0, 800, 600);
        panel1.setBackground(Color.BLACK);
        panel1.setLayout(null);
        add(panel1);
        
        
        ImageIcon logoI = new ImageIcon(getClass().getClassLoader().getResource("Imagenes/jas2.png"));
        ImageIcon logoS = new ImageIcon(logoI.getImage().getScaledInstance(270, 250, Image.SCALE_DEFAULT));
        logo = new JLabel(logoS);
        panel1.add(logo);
        logo.setSize(270, 250);
        logo.setLocation(120, 50);
        //logo.setIcon(new ImageIcon("C:\\Users\\julian\\Desktop\\jas2.png"));
        
        usuario = new JLabel();
        panel1.add(usuario);
        usuario.setSize(100, 100);
        usuario.setFont(ingreso);
        usuario.setForeground(Color.WHITE);
        usuario.setLocation(60, 320);
        usuario.setText("Nombre:");
        
        contraseña = new JLabel();
        panel1.add(contraseña);
        contraseña.setSize(100, 100);
        contraseña.setFont(ingreso);
        contraseña.setForeground(Color.WHITE);
        contraseña.setLocation(70, 370);
        contraseña.setText("Codigo:");
        
        usuarioE = new JTextField();
        panel1.add(usuarioE);
        usuarioE.setSize(220, 25);
        usuarioE.setLocation(155, 352);
        usuarioE.setFont(new Font("Calibri", Font.BOLD, 22) {});
        
        codigoE = new JTextField();
        codigoE.setDocument(new LimitadorCaracteres(codigoE, 9, 0)); 
        panel1.add(codigoE);
        codigoE.setSize(220, 25);
        codigoE.setLocation(155, 400);
        codigoE.setFont(new Font("Calibri", Font.BOLD, 22) {});
        
        ingresar = new JButton("Ingresar");
        panel1.add(ingresar);
        ingresar.setBounds(280, 480, 120, 40);
        ingresar.setBackground(Color.BLACK);
        ingresar.setFont(ingreso);
        ingresar.setForeground(Color.WHITE);
        
        ingresar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                evento_Entrada();
            }
        });
        
        registrar = new JButton("Registrar");
        panel1.add(registrar);
        registrar.setBounds(110, 480, 120, 40);
        registrar.setBackground(Color.BLACK);
        registrar.setFont(ingreso);
        registrar.setForeground(Color.WHITE);
        
        registrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                evento_Registrar();
            }
        });
        
        salir = new JButton("Salir");
        panel1.add(salir);
        salir.setBounds(360, 10, 140, 40);
        salir.setBackground(Color.BLACK);
        salir.setFont(ingreso);
        salir.setBorder(null);
        salir.setForeground(Color.WHITE);
        botonSalir(); 
        
        
        
        
    }
    
    private void evento_Registrar() {
        boolean veri=false;
        veri=validacionBase();
        if(veri){
            JOptionPane.showMessageDialog(null, "Codigo existente");
        }else{
            try {
                //dato.add(tmp);..
                
                evento_Extraer();
            } catch (IOException ex) {
                Logger.getLogger(ProyectoFinal.class.getName()).log(Level.SEVERE, null, ex);
            }
            JOptionPane.showMessageDialog(null,"Usuario registrado");
            
        }
    }
    
    private void evento_Entrada() {
        boolean cod=false, nom=false;
        Datos tmp = new Datos();
        tmp.nombre = usuarioE.getText();
        tmp.codigo = codigoE.getText();
        
        cod = validacionBase();
        if(cod){
            setVisible(false);
            MenuPrincipal mp = new MenuPrincipal();
        }
        else{
            JOptionPane.showMessageDialog(null, "Usuario no registrado");
        }
     
    }
    
    private void evento_Extraer() throws IOException {
        boolean error= false;
        try {
            archivo = new FileWriter("usuarios.csv", true);
        } catch (IOException e) {
            error= true;
            JOptionPane.showMessageDialog(null, "error = "+ e);
        }
        if(!error){
            
            archivo.write(usuarioE.getText()+";"+codigoE.getText()+"\r\n");//Hola
            
        }
        try {
            archivo.close();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error al cerrar el archivo");
        }
        
    }
    
    public boolean validacionBase(){
        boolean veri = false, error = false;
        
        try {
            leer = new FileReader("usuarios.csv");
        } catch (IOException e) {
            error = true;
            JOptionPane.showMessageDialog(null, "Error" + e);
        }
        if(!error){
            BufferedReader read = new BufferedReader(leer);
            String registro;
            String tokens[] = new String[2];
            try {
                while ((registro = read.readLine())!= null) { 
                    tokens = registro.split(";");
                    for (int i = 0; i < tokens.length; i++) {
                        
                        if(i%2==1){
                            if(tokens[i].equals(codigoE.getText())){
                                veri = true;
                            }
                        }
                        
                    }
                    
                }
                
                
            } catch (IOException e) {
                JOptionPane.showMessageDialog(null, "Error " + e);
            }
        }
        
        try {
            leer.close();
        } catch (IOException e) {
        }
        
        
        return veri;
    }
    
    public void botonSalir(){
        salir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        } );
    }
    
    
    public static void main(String[] args) {
        ProyectoFinal obj = new ProyectoFinal();
    }
    
}
