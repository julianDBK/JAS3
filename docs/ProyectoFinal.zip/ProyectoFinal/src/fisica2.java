


import java.awt.Color;
import java.awt.Cursor;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;


public class fisica2 extends JFrame{
    
    JPanel contenido;
    JButton jugar, salir;
    JLabel fondo;
    
    public fisica2(){
        super();
        setSize(1200, 800);
        setLocationRelativeTo(null);
        setLayout(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        crearGUI();
        
        setVisible(true);
    }
    
    public void crearGUI(){
        
        contenido = new JPanel();
        contenido.setLayout(null);
        contenido.setBounds(20, 20, 1150, 700);
        contenido.setBackground(Color.red);
        crearBotones();
        crearFondo();
        
        
        add(contenido);
        
    }
    
    public void crearBotones(){
        jugar = new JButton();
        jugar.setBounds(730, 190, 270, 70);
        jugar.setBackground(Color.red);
        jugar.setOpaque(false);
        jugar.setToolTipText("Click Aqui");
        jugar.setBorder(null);
        jugar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                eventoJugar();
            }
        });
        jugar.setContentAreaFilled(false);
        jugar.setCursor(new Cursor(HAND_CURSOR));
        
        contenido.add(jugar);
        
        salir = new JButton();
        salir.setBounds(730, 400, 270, 70);
        salir.setBackground(Color.red);
        salir.setOpaque(false);
        salir.setContentAreaFilled(false);
        salir.setToolTipText("Click Aqui");
        salir.setBorder(null);
        salir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                eventoSalir();
            }
        });
        salir.setCursor(new Cursor(HAND_CURSOR));
        
        contenido.add(salir);
        
    }
    
    
    public void eventoJugar(){
        dispose();
        cuestionario jugar = new cuestionario();
    }
    
    public void eventoSalir(){
        dispose();
        MenuPrincipal nuevo = new MenuPrincipal();
    }
    
    public void crearFondo() {
        ImageIcon logoI = new ImageIcon(getClass().getClassLoader().getResource("Imagenes/seccionInicio.jpg"));
        ImageIcon logoS = new ImageIcon(logoI.getImage().getScaledInstance(contenido.getWidth(), contenido.getHeight(), Image.SCALE_DEFAULT));
        fondo = new JLabel(logoS);

        fondo.setSize(contenido.getWidth(), contenido.getHeight());
        fondo.setLocation(0, 0);

        contenido.add(fondo);
    }
    
}
