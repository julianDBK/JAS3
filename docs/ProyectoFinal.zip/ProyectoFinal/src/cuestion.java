
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.*;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

public class cuestion extends JFrame implements ActionListener {

    JPanel contenido;
    JLabel titulo;
    JButton jbAnterior, jbSiguiente;
    Humanidades hm;
    JTextArea pregunta;
    JRadioButton respuesta1, respuesta2, respuesta3;

    Font tit = new Font("Times New Roman", Font.PLAIN, 30);
    Font preg = new Font("Times new roman", Font.BOLD, 20);
    ArrayList<GenerarPreguntas> nuevo = new ArrayList<>();

    int cont = 0, cantCo = 0, seleccion = 0, intento=1, aux=0;

    ButtonGroup grupoBotones;

    public cuestion(Humanidades ob) {
        super("Cuestionario");
        hm = ob;
        setSize(600, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
        getContentPane().setBackground(Color.BLACK);
        Image icono = new ImageIcon(getClass().getResource("Imagenes/Logo.png")).getImage();
        setIconImage(icono);
        setLayout(null);

        crearGUI();
        setVisible(true);
    }

    public void crearGUI() {

        contenido = new JPanel();
        contenido.setLayout(null);
        contenido.setBounds(40, 30, 500, 350);
        contenido.setBackground(Color.white);

        generarPreguntas();

        setTitulo();
        Iniciar();
        crearBotones();

        add(contenido);

        //-----------------------------------------------------------------------------
    }

    private void setTitulo() {
        titulo = new JLabel("Pregunta  #" + (cont + 1));
        titulo.setFont(tit);
        titulo.setBounds(180, 30, 200, 40);
        contenido.add(titulo);
    }

    public void generarPreguntas() {
        int indi = 0;
        do {
            GenerarPreguntas generar = new GenerarPreguntas();
            generar.generar();
            //JOptionPane.showMessageDialog(null, indi + generar.getPregunta());
            nuevo.add(generar);
            indi++;
        } while (indi < 5);
    }

    public void Iniciar() {

        GenerarPreguntas tmp = nuevo.get(cont);

        contenido.setVisible(true);
        pregunta = new JTextArea();
        pregunta.setLayout(null);
        pregunta.setText((cont + 1) + ".  " + tmp.getPregunta());
        pregunta.setBounds(30, 100, 430, 50);
        pregunta.setFont(preg);
        pregunta.setWrapStyleWord(true);
        pregunta.setLineWrap(true);
        pregunta.setForeground(Color.BLACK);
        pregunta.setOpaque(false);
        pregunta.setEditable(false);
        pregunta.setEnabled(true);

        contenido.add(pregunta);

        respuesta1 = new JRadioButton(tmp.getResp_1());
        respuesta1.setBounds(40, 170, 400, 40);
        respuesta1.setOpaque(false);

        contenido.add(respuesta1);

        respuesta2 = new JRadioButton(tmp.getResp_2());
        respuesta2.setBounds(40, 230, 400, 40);
        respuesta2.setOpaque(false);

        contenido.add(respuesta2);

        respuesta3 = new JRadioButton(tmp.getResp_3());
        respuesta3.setBounds(40, 290, 400, 40);
        respuesta3.setOpaque(false);

        contenido.add(respuesta3);

        grupoBotones = new ButtonGroup();
        grupoBotones.add(respuesta1);
        grupoBotones.add(respuesta2);
        grupoBotones.add(respuesta3);

        respuesta1.addActionListener(this);
        respuesta2.addActionListener(this);
        respuesta3.addActionListener(this);

    }

    private void crearBotones() {
        jbSiguiente = new JButton("Siguiente");
        jbSiguiente.setBounds(430, 400, 130, 40);
        jbSiguiente.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                evento_Siguiente();
            }
        });
        add(jbSiguiente);

        jbAnterior = new JButton("Anterior");
        jbAnterior.setBounds(30, 400, 130, 40);
        jbAnterior.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                evento_Anterior();
            }
        });
        add(jbAnterior);
    }

    //---------------------
    public void setSiguiente() {
        GenerarPreguntas tmp = nuevo.get(cont);
        //contenido.setVisible(true);
        pregunta.setText((cont + 1) + ".  " + tmp.getPregunta());
        respuesta1.setText(tmp.getResp_1());
        respuesta2.setText(tmp.getResp_2());
        respuesta3.setText(tmp.getResp_3());
    }

    public void evento_jbVolver() {
        setVisible(false);
        dispose();
        hm.setVisible(true);
    }

    public void comprobar() {
        GenerarPreguntas tmp = nuevo.get(cont);
        if (seleccion == tmp.getPos() - (tmp.getPos() - 1)) {
            cantCo++;
            aux++;
            System.out.println("Correcto");
        } else {
            System.out.println("Incorrecto");
        }
    }

    public void evento_Siguiente() {

        comprobar();
        seleccion=0;
        if (cont <= 3) {
            cont++;
            titulo.setText("");
            pregunta.setText("");
            respuesta1.setText("");
            respuesta2.setText("");
            respuesta3.setText("");
            setTitulo();
            setSiguiente();
            grupoBotones.clearSelection();
        } else {
            JOptionPane.showMessageDialog(null, "Cantidad de respuestas correctas = " + cantCo);
            jbAnterior.setVisible(false);
            
            int respuesta = JOptionPane.showConfirmDialog(this, "¿Desea reintentar el cuestionario?",
                    "Confirmacion",
                    JOptionPane.YES_NO_OPTION);
            if (respuesta == JOptionPane.YES_OPTION && intento<2) {
                cont=0; cantCo=0; intento++;
                nuevo.clear();
                generarPreguntas();
                setTitulo();
                setSiguiente();
                jbAnterior.setVisible(true);
            } else {
                JOptionPane.showMessageDialog(null, "Envio de correo");
                envioCorreo eje = new envioCorreo(Double.valueOf(aux), Double.valueOf(intento));
                setVisible(false);
            }
            
        }
    }

    public void evento_Anterior() {
        if (cont >= 1) {
            cont--;
            compCorrecto();
            titulo.setText("");
            pregunta.setText("");
            respuesta1.setText("");
            respuesta2.setText("");
            respuesta3.setText("");
            setTitulo();
            setSiguiente();
            grupoBotones.clearSelection();
        }

    }

    public void compCorrecto() {
        if (seleccion == 1) {
            cantCo--;
        }
    }

    //------------------------------------------------------- Acciones
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == respuesta1) {
            seleccion = 1;
            System.out.println("Resp 1");
        }
        if (e.getSource() == respuesta2) {
            seleccion = 2;
            System.out.println("Resp 2");
        }
        if (e.getSource() == respuesta3) {
            seleccion = 3;
            System.out.println("Resp 3");
        }
    }

}
