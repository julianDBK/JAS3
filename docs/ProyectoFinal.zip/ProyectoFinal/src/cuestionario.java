

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class cuestionario extends JFrame {

    JLabel Preguntas;
    JTextArea pregunta1, primRespuesta, segRespuesta, terRespuesta;
    JButton R1, R2, R3, R4;
    JButton jbAnterior, jbSiguiente, calificacion;
    JPanel contenido;
    JLabel fondo;

    Font tit = new Font("Times New Roman", Font.PLAIN, 25);
    Font preg = new Font("Times New Roman", Font.PLAIN, 17);
    bancoPreguntas banco = new bancoPreguntas();

    int posicionPregunta = 1;
    double puntaje;
    String preguntas[] = new String[3];

    public cuestionario() {
        super("CUESTIONARIO FISICA");
        setSize(1300, 850);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
        getContentPane().setBackground(Color.BLACK);
        /*Image icono = new ImageIcon(getClass().getResource("Imagenes/Logo.png")).getImage();
        setIconImage(icono);*/
        setLayout(null);
        banco.generarPregunta();
        crearGUI();
        setVisible(true);
    }

    public void crearGUI() {
        contenido = new JPanel();
        contenido.setLayout(null);
        contenido.setBounds(40, 40, 1200, 740);

        //generarPreguntas();
        //Iniciar();
        crearBotones();
        setTitulo();
        crearFondo();
        add(contenido);

    }

    public void crearFondo() {
        ImageIcon logoI = new ImageIcon(getClass().getClassLoader().getResource("./imagenes/seccionMenu.jpg"));
        ImageIcon logoS = new ImageIcon(logoI.getImage().getScaledInstance(contenido.getWidth(), contenido.getHeight(), Image.SCALE_DEFAULT));
        fondo = new JLabel(logoS);

        fondo.setSize(contenido.getWidth(), contenido.getHeight());
        fondo.setLocation(0, 0);

        contenido.add(fondo);
    }

    public void setTitulo() {

        pregunta1 = new JTextArea(preguntas(banco.getPregunta(posicionPregunta)));
        pregunta1.setFont(tit);
        pregunta1.setBounds(240, 280, 350, 180);
        pregunta1.setOpaque(false);
        pregunta1.setWrapStyleWord(true);
        pregunta1.setLineWrap(true);

        pregunta1.setForeground(Color.white);

        contenido.add(pregunta1);

    }

    public void setRespuestas() {

        int preg[] = new int[3];
        int num1, num2, num3;
        preg = banco.respuestas(posicionPregunta);

        num1 = (int) (Math.random() * 3);

        primRespuesta.setText(opcionesRespuestas(preg[num1]));

        do {
            num2 = (int) (Math.random() * 3);
        } while (num2 == num1);

        segRespuesta.setText(opcionesRespuestas(preg[num2]));

        do {
            num3 = (int) (Math.random() * 3);
        } while (num3 == num1 || num3 == num2);

        terRespuesta.setText(opcionesRespuestas(preg[num3]));

    }

    private void crearBotones() {

        calificacion = new JButton("Salir");
        calificacion.setBounds(300, 570, 250, 60);
        calificacion.setToolTipText("Click Aqui");
        calificacion.setCursor(new Cursor(Cursor.HAND_CURSOR));
        calificacion.setBackground(Color.black);
        calificacion.setForeground(Color.white);
        calificacion.setFont(tit);
        calificacion.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                eventoSalir();
            }
        });
        add(calificacion);

// OPCIONES DE RESPUESTA
        R1 = new JButton();
        R1.setLayout(null);
        R1.setBounds(770, 215, 320, 80);
        R1.setBackground(Color.red);
        R1.setBorder(null);
        R1.setOpaque(false); /// AQUI LO OCULTO
        R1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                evento_Siguiente(1);
            }
        });
        R1.setContentAreaFilled(false);
        R1.setCursor(new Cursor(Cursor.HAND_CURSOR));
        add(R1);

        R2 = new JButton("");
        R2.setLayout(null);
        R2.setBounds(770, 360, 320, 80);
        R2.setBackground(Color.green);
        R2.setBorder(null);
        R2.setOpaque(false); /// AQUI LO OCULTO
        R2.setCursor(new Cursor(Cursor.HAND_CURSOR));
        R2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                evento_Siguiente(2);
            }
        });
        R2.setContentAreaFilled(false);
        add(R2);

        R3 = new JButton("");
        R3.setLayout(null);
        R3.setBounds(770, 518, 320, 80);
        R3.setBackground(Color.green);
        R3.setBorder(null);
        R3.setOpaque(false); /// AQUI LO OCULTO
        R3.setCursor(new Cursor(Cursor.HAND_CURSOR));
        R3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                evento_Siguiente(3);
            }
        });
        R3.setContentAreaFilled(false);
        add(R3);

        // TEXTO RESPUESTA
        primRespuesta = new JTextArea();
        primRespuesta.setFont(preg);
        primRespuesta.setBounds(790, 225, 290, 70);
        primRespuesta.setOpaque(false);
        primRespuesta.setEditable(false);
        primRespuesta.setWrapStyleWord(true);
        primRespuesta.setLineWrap(true);

        primRespuesta.setForeground(Color.white);
        add(primRespuesta);

        segRespuesta = new JTextArea();
        segRespuesta.setFont(preg);
        segRespuesta.setBounds(790, 370, 290, 70);
        segRespuesta.setOpaque(false);
        segRespuesta.setEditable(false);
        segRespuesta.setWrapStyleWord(true);
        segRespuesta.setLineWrap(true);

        segRespuesta.setForeground(Color.white);
        add(segRespuesta);

        terRespuesta = new JTextArea();
        terRespuesta.setFont(preg);
        terRespuesta.setBounds(790, 525, 290, 70);
        terRespuesta.setOpaque(false);
        terRespuesta.setEditable(false);
        terRespuesta.setWrapStyleWord(true);
        terRespuesta.setLineWrap(true);

        terRespuesta.setForeground(Color.white);
        add(terRespuesta);

        setRespuestas();

    }

    public void calcularPunto(int seleccion) {
        String respuesta = "";
        boolean veri = false;

        switch (seleccion) {
            case 1:
                if (primRespuesta.getText().equals(opcionesRespuestas(banco.getPregunta(posicionPregunta)))) {
                    JOptionPane.showMessageDialog(null, "Correcto");
                    veri = true;
                } else {
                    JOptionPane.showMessageDialog(null, "Incorrecto");
                }
                break;
            case 2:
                if (segRespuesta.getText().equals(opcionesRespuestas(banco.getPregunta(posicionPregunta)))) {
                    JOptionPane.showMessageDialog(null, "Correcto");
                    veri = true;
                } else {
                    JOptionPane.showMessageDialog(null, "Incorrecto");
                }
                break;
            case 3:
                if (terRespuesta.getText().equals(opcionesRespuestas(banco.getPregunta(posicionPregunta)))) {
                    JOptionPane.showMessageDialog(null, "Correcto");
                    veri = true;
                } else {
                    JOptionPane.showMessageDialog(null, "Incorrecto");
                }
                break;
        }

        if (veri) {
            puntaje++;
        }
    }

    public void evento_Siguiente(int seleccion) {

        calcularPunto(seleccion);

        posicionPregunta++;

        contenido.setVisible(false);
        pregunta1.setText(preguntas(banco.getPregunta(posicionPregunta)));

        setRespuestas();

        contenido.setVisible(true);
        //setTitulo();
        
        if(posicionPregunta == 11) eventoSalir();
    }
    
    

    
    
    public void eventoSalir(){
        JOptionPane.showMessageDialog(null, "Cantidad Correctas  =  " +  puntaje +"\nTotal Preguntas  =  " + posicionPregunta);
        dispose();
        fisica2 eje = new fisica2();
    }

    public String preguntas(int pos) {
        String pregunta = "";
        switch (pos) {

            case 1:
                pregunta = "1. ¿Qué es electromagnetismo?";
                break;
            case 2:
                pregunta = "2. ¿Cuáles son los focos más frecuentes de contaminación electromagnética de extremadamente bajas frecuencias?";
                break;
            case 3:
                pregunta = "3. ¿Por qué nos afectan los campos electromagnéticos?";
                break;
            case 4:
                pregunta = "4. ¿Cuándo existe riesgo?";
                break;
            case 5:
                pregunta = "5. ¿A partir de qué dosis existe riesgo?";
                break;
            case 6:
                pregunta = "6. ¿Cuáles son las fuentes más comunes de contaminación?";
                break;
            case 7:
                pregunta = "7.¿Qué efectos tiene la ncontaminación electromagnética en el cuerpo humano?";
                break;
            case 8:
                pregunta = "8. ¿Cómo podemos reducir la contaminación electromagnética en nuestro entorno?";
                break;
            case 9:
                pregunta = "9. ¿Cuál es la agencia encargada de regular la contaminación electromagnética?";
                break;
            case 10:
                pregunta = "10. ¿Qué significa la sigla SAR?";
                break;
            case 11:
                pregunta = "11. ¿Cómo se puede medir la radiación electromagnética?";
                break;
            case 12:
                pregunta = "12. ¿Cuál es el rango de frecuencia de los campos electromagnéticos no ionizantes?";
                break;
            case 13:
                pregunta = "13. ¿Qué es el efecto de pantalla en la contaminación electromagnética?";
                break;
            case 14:
                pregunta = "14. ¿Qué es la radiación ionizante?";
                break;
            case 15:
                pregunta = "15. ¿Qué es el campo electromagnético de radiofrecuencia?";
                break;
            case 16:
                pregunta = "16. ¿Cuál es la diferencia entre un campo eléctrico y un campo magnético?";
                break;
            case 17:
                pregunta = "17. ¿Qué es el efecto Faraday en relación con la contaminación electromagnética?";
                break;
            case 18:
                pregunta = "18. ¿Qué es la interferencia electromagnética?";
                break;
            case 19:
                pregunta = "19. ¿Cuál es el organismo internacional encargado de establecer los límites de exposición a la radiación electromagnética?";
                break;
            case 20:
                pregunta = "20. ¿Qué precauciones se pueden tomar para reducir la exposición a la contaminación electromagnética en el hogar?";
                break;
        }

        return pregunta;
    }

    public String opcionesRespuestas(int pos) {
        String pregunta = "";

        /*
        
        1.	Presencia excesiva de campos, causada por dispositivos y redes inalámbricas
2.	antenas de telefonía, radio y televisión.
3.	Se pueden presentar alergias debido a que el cuerpo presenta corrientes eléctricas muy bajas 
4.	Cuando se da exposición alta con líneas eléctricas y otros dispositivos electrónicos
5.	2 mili Gauss (200 nano Teslas – 0.2 micro teslas)
6.	Telefonía móvil, radios y televisores, redes wifi, etc
7.	Dolores de cabeza, trastornos del sueño y problemas de concentración 
8.	Tomar medidas de distanciamiento con los dispositivos electrónicos
9.	Comisión federal de comunicaciones
10.	Tasa de Absorción Específica
11.	medidores de campo electromagnético.
12.	Va desde los 0 Hz (corriente continua) hasta los 300 GHz.
13.	reducción de la intensidad del campo electromagnético debido a la presencia de obstáculos físicos.
14.	radiación electromagnética con suficiente energía para ionizar átomos y moléculas, como los rayos X y la radiación nuclear.
15.	campo electromagnético generado por dispositivos inalámbricos y redes de comunicación
16.	Uno es generado por cargas eléctricas y el otro por corrientes eléctricas
17.	Capacidad de un material para bloquear o atenuar los campos electromagnéticos.
18.	perturbación de señales o dispositivos electrónicos debido a la presencia de campos electromagnéticos no deseados
19.	Comisión Internacional de Protección contra la Radiación No Ionizante
20.	Apagar dispositivos cuando no se utilizan y mantener una distancia adecuada

        
         */
        switch (pos) {

            case 1:
                pregunta = "Presencia excesiva de campos, causada por dispositivos y redes inalámbricas";
                break;
            case 2:
                pregunta = "antenas de telefonía, radio y televisión.";
                break;
            case 3:
                pregunta = "Se pueden presentar alergias debido a que el cuerpo presenta corrientes eléctricas muy bajas ";
                break;
            case 4:
                pregunta = "Cuando se da exposición alta con líneas eléctricas y otros dispositivos electrónicos";
                break;
            case 5:
                pregunta = "2 mili Gauss (200 nano Teslas – 0.2 micro teslas)";
                break;
            case 6:
                pregunta = "Telefonía móvil, radios y televisores, redes wifi, etc";
                break;
            case 7:
                pregunta = "Dolores de cabeza, trastornos del sueño y problemas de concentración ";
                break;
            case 8:
                pregunta = "Tomar medidas de distanciamiento con los dispositivos electrónicos";
                break;
            case 9:
                pregunta = "Comisión federal de comunicaciones";
                break;
            case 10:
                pregunta = "Tasa de Absorción Específica";
                break;
            case 11:
                pregunta = "medidores de campo electromagnético.";
                break;
            case 12:
                pregunta = "Va desde los 0 Hz (corriente continua) hasta los 300 GHz.";
                break;
            case 13:
                pregunta = "reducción de la intensidad del campo electromagnético debido a la presencia de obstáculos físicos.";
                break;
            case 14:
                pregunta = "radiación electromagnética con suficiente energía para ionizar átomos y moléculas, como los rayos X y la radiación nuclear.";
                break;
            case 15:
                pregunta = "campo electromagnético generado por dispositivos inalámbricos y redes de comunicación";
                break;
            case 16:
                pregunta = "Uno es generado por cargas eléctricas y el otro por corrientes eléctricas";
                break;
            case 17:
                pregunta = "Capacidad de un material para bloquear o atenuar los campos electromagnéticos.";
                break;
            case 18:
                pregunta = "perturbación de señales o dispositivos electrónicos debido a la presencia de campos electromagnéticos no deseados";
                break;
            case 19:
                pregunta = "Comisión Internacional de Protección contra la Radiación No Ionizante";
                break;
            case 20:
                pregunta = "Apagar dispositivos cuando no se utilizan y mantener una distancia adecuada";
                break;
        }

        return pregunta;

    }

}
