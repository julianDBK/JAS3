import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;
import javax.swing.border.BevelBorder;

public class Matematicas extends JFrame {

    JButton jbVolver, jbCalcDeriv, video;
    JLabel jlImage, jlTexto;
    MenuPrincipal mp;
    JTextArea jtDeri, jtTrig, jtImpl, jtDesc, jtExp;
    Color fondo = new Color(231, 75, 50);

    public Matematicas(MenuPrincipal obj) {
        super("MATEMATICAS");
        mp = obj;
        setSize(800, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
        getContentPane().setBackground(Color.BLACK);
        Image icono = new ImageIcon(getClass().getResource("Imagenes/Logo.png")).getImage();
        setIconImage(icono);
        setLayout(null);
        //addMouseListener(this);
        crearGUI();
        setVisible(true);

    }

    public void crearGUI() {
        jbVolver = new JButton("Volver");
        jbVolver.setBounds(30, 505, 150, 40);
        jbVolver.setToolTipText("Click Aqui");
        jbVolver.setCursor(new Cursor(Cursor.HAND_CURSOR));
        jbVolver.setOpaque(false);
        jbVolver.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
        jbVolver.setBorderPainted(true);
        jbVolver.setOpaque(true);
        jbVolver.setBackground(Color.WHITE);
        jbVolver.setFocusPainted(false);
        jbVolver.setForeground(Color.BLACK);
        jbVolver.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                evento_jbVolver();
            }
        });
        add(jbVolver);

        jbCalcDeriv = new JButton("Calculadora de Derivadas");
        jbCalcDeriv.setBounds(604, 505, 150, 40);
        jbCalcDeriv.setToolTipText("Click Aqui");
        jbCalcDeriv.setCursor(new Cursor(Cursor.HAND_CURSOR));
        jbCalcDeriv.setOpaque(false);
        jbCalcDeriv.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
        jbCalcDeriv.setBorderPainted(true);
        jbCalcDeriv.setOpaque(true);
        jbCalcDeriv.setBackground(Color.WHITE);
        jbCalcDeriv.setFocusPainted(false);
        jbCalcDeriv.setForeground(Color.BLACK);
        jbCalcDeriv.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                evento_jbCalcDeriv();
            }
        });
        add(jbCalcDeriv);

        jlTexto = new JLabel("DERIVADAS");
        jlTexto.setBounds(0, 0, 800, 80);
        jlTexto.setOpaque(false);
        jlTexto.setBackground(Color.BLACK);
        jlTexto.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 30));
        jlTexto.setForeground(Color.WHITE);
        jlTexto.setHorizontalAlignment(SwingConstants.CENTER);
        add(jlTexto);

        jtDeri = new JTextArea(" Derivadas");
        jtDeri.setWrapStyleWord(true);
        jtDeri.setLineWrap(true);
        jtDeri.setBounds(30, 90, 100, 30);
        jtDeri.setFont(new Font("Times New Roman", Font.BOLD, 20));
        jtDeri.setOpaque(false);
        jtDeri.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
        jtDeri.setBackground(Color.WHITE);
        jtDeri.setForeground(Color.WHITE);
        jtDeri.setEnabled(true);
        jtDeri.setEditable(false);

        add(jtDeri);

        jtDesc = new JTextArea("El concepto de derivada se aplica en los casos donde es necesario medir la rapidez con que se produce el cambio de una situación. Por ello, es una herramienta de cálculo fundamental en los estudios de Física, Química y Biología.");
        jtDesc.setWrapStyleWord(true);
        jtDesc.setLineWrap(true);
        jtDesc.setBounds(150, 70, 600, 100);
        jtDesc.setOpaque(true);
        jtDesc.setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED));
        jtDesc.setFont(new Font("Times New Roman", Font.BOLD, 20));
        jtDesc.setOpaque(false);
        jtDesc.setForeground(Color.WHITE);
        jtDesc.setEnabled(true);
        jtDesc.setEditable(false);

        add(jtDesc);

        jtTrig = new JTextArea("Importancia de la derivada\n\nLa derivada es una herramienta de gran utilidad en economía puesto que nos permite realizar cálculos marginales, es decir, hallar la razón de cambio cuando se agrega una unidad adicional al total, sea cual sea la cantidad económica que se esté estudiando");
        jtTrig.setWrapStyleWord(true);
        jtTrig.setLineWrap(true);
        jtTrig.setBounds(20, 190, 200, 300);
        jtTrig.setOpaque(true);
        jtTrig.setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED));
        jtTrig.setFont(new Font("Tahoma", Font.BOLD, 15));
        jtTrig.setOpaque(false);
        jtTrig.setForeground(Color.WHITE);
        jtTrig.setEnabled(true);
        jtTrig.setEditable(false);

        add(jtTrig);
        
        jtImpl = new JTextArea("Las derivadas son esenciales para estudios tan importantes como el de la relatividad, la mecánica cuántica, la ingeniería, ecuaciones diferenciales, teoría de las probabilidades, sistemas dinámicos, teoría de las funciones, etc. Actualmente también son necesarios en la computación, etc");
        jtImpl.setWrapStyleWord(true);
        jtImpl.setLineWrap(true);
        jtImpl.setBounds(290, 190, 200, 300);
        jtImpl.setOpaque(true);
        jtImpl.setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED));
        jtImpl.setFont(new Font("Tahoma", Font.BOLD, 15));
        jtImpl.setOpaque(false);
        jtImpl.setForeground(Color.WHITE);
        jtImpl.setEnabled(true);
        jtImpl.setEditable(false);

        add(jtImpl);

        jtExp = new JTextArea("Derivada Parcial\n\nLa derivada parcial de una función de varias variables es la derivada con respecto a cada una de esas variables manteniendo las otras como constantes. \nLas derivadas parciales son usadas en cálculo vectorial y geometría diferencial.");
        jtExp.setWrapStyleWord(true);
        jtExp.setLineWrap(true);
        jtExp.setBounds(560, 190, 200, 300);
        jtExp.setOpaque(true);
        jtExp.setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED));
        jtExp.setFont(new Font("Tahoma", Font.BOLD, 15));
        jtExp.setOpaque(false);
        jtExp.setForeground(Color.WHITE);
        jtExp.setEnabled(true);
        jtExp.setEditable(false);

        add(jtExp);

        ImageIcon logo = new ImageIcon(getClass().getResource("Imagenes/Negro.jpg"));
        ImageIcon imgEscalada2 = new ImageIcon(logo.getImage().getScaledInstance(800, 600, Image.SCALE_DEFAULT));
        jlImage = new JLabel(imgEscalada2);
        jlImage.setBounds(0, 0, 800, 600);
        add(jlImage);
    }

    public void evento_jbVolver() {
        setVisible(false);
        dispose();
        mp.setVisible(true);

    }
    
    public void evento_jbCalcDeriv(){
        CalcDeriv derv = new CalcDeriv(this);
        dispose();
        setVisible(false);
    }
}
