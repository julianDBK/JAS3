
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.text.DecimalFormat;
import javax.swing.ImageIcon;
import javax.swing.*;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;
import javax.swing.border.BevelBorder;
import javax.swing.event.MouseInputListener;

/**
 *
 * @author theca
 */
public class Juego extends JFrame implements MouseInputListener {

    //---------------------------------------- Componentes
    JPanel pContenido, pVisualizar;

    JLabel eAltura, eDistancia, eFuerza, ePeso, eDistanciaRecorrida, eAceleracion, eTiempo, ganaste;//Titulos
    JTextField ingAltura, ingDistancia, ingFuerza, ingPeso, MosDistancia, MosGravedad, MosTiempo;

    JComboBox<String> ingGravedad;

    JButton bEjecutar;

    //--------------------------------------- Variables
    int altPersonaje = 550, disObjeto = 300, fuerza = 0, peso = 0, cont = 0;
    double gravedad = 0, tiempo = 0, altura, distancia;
    MenuPrincipal mp;
    Font etiqueta = new Font("Times new Roman", Font.BOLD, 20);

    //Fisica obj;
    
    public Juego() {
        super("MiniJuego");
        addMouseListener(this);
        //obj = fi;
        setSize(1200, 750);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
        getContentPane().setBackground(Color.BLACK);
        Image icono = new ImageIcon(getClass().getResource("Imagenes/Logo.png")).getImage();
        setIconImage(icono);
        setLayout(null);
        crearGUI();
        setVisible(true);
    }

    public void crearGUI() {

        //----------------------------------------- JPanel  
        ganaste = new JLabel();
        ganaste.setBounds(850, 615, 200, 30);
        ganaste.setBackground(Color.WHITE);
        ganaste.setForeground(Color.RED);
        ganaste.setOpaque(true);
        ganaste.setFont(etiqueta);
        add(ganaste);

        pContenido = new JPanel();
        pContenido.setBounds(800, 20, 360, 500);
        pContenido.setLayout(null);
        pContenido.setBackground(Color.BLACK);
        
        add(pContenido);

        pVisualizar = new JPanel();
        pVisualizar.setBounds(20, 530, 1140, 160);
        pVisualizar.setLayout(null);
        pVisualizar.setBackground(Color.BLACK);
        add(pVisualizar);

        //---------------------------------------- JLabel
        eDistancia = new JLabel("Distancia");
        eDistancia.setBounds(45, 50, 100, 40);
        eDistancia.setForeground(Color.WHITE);
        eDistancia.setFont(etiqueta);
        pContenido.add(eDistancia);

        eFuerza = new JLabel("Fuerza");
        eFuerza.setBounds(45, 120, 100, 40);
        eFuerza.setForeground(Color.WHITE);
        eFuerza.setFont(etiqueta);
        pContenido.add(eFuerza);

        eAltura = new JLabel("Altura");
        eAltura.setBounds(45, 190, 100, 40);
        eAltura.setForeground(Color.WHITE);
        eAltura.setFont(etiqueta);
        pContenido.add(eAltura);

        ePeso = new JLabel("Peso");
        ePeso.setBounds(45, 260, 100, 40);
        ePeso.setForeground(Color.WHITE);
        ePeso.setFont(etiqueta);
        pContenido.add(ePeso);

        //---------------
        eDistanciaRecorrida = new JLabel("Distancia Recorrida");
        eDistanciaRecorrida.setBounds(80, 30, 200, 40);
        eDistanciaRecorrida.setForeground(Color.WHITE);
        eDistanciaRecorrida.setFont(etiqueta);
        pVisualizar.add(eDistanciaRecorrida);

        eAceleracion = new JLabel("Gravedad");
        eAceleracion.setBounds(340, 30, 200, 40);
        eAceleracion.setForeground(Color.WHITE);
        eAceleracion.setFont(etiqueta);
        pVisualizar.add(eAceleracion);

        eTiempo = new JLabel("Tiempo de Caida");
        eTiempo.setBounds(540, 30, 200, 40);
        eTiempo.setForeground(Color.WHITE);
        eTiempo.setFont(etiqueta);
        pVisualizar.add(eTiempo);

        //Mercurio venis tierra marte jupiter saturno neptuno urano
        ingGravedad = new JComboBox<>();
        ingGravedad.addItem("Tierra");
        ingGravedad.addItem("Marte");
        ingGravedad.addItem("Venus");
        ingGravedad.addItem("Mercurio");
        ingGravedad.addItem("Saturno");
        ingGravedad.addItem("Neptuno");
        ingGravedad.addItem("Urano");
        ingGravedad.addItem("Jupiter");

        ingGravedad.setBounds(80, 330, 200, 40);
        ingGravedad.setFont(new Font("Times new Roman", Font.PLAIN, 20));
        pContenido.add(ingGravedad);

        //---------------------------------------- JTfield
        ingDistancia = new JTextField();
        ingDistancia.setBounds(135, 55, 150, 30);
        ingDistancia.setText("200");
        pContenido.add(ingDistancia);

        ingFuerza = new JTextField();
        ingFuerza.setBounds(135, 125, 150, 30);
        ingFuerza.setText("0");
        pContenido.add(ingFuerza);

        ingAltura = new JTextField();
        ingAltura.setBounds(135, 195, 150, 30);
        ingAltura.setText("100");
        pContenido.add(ingAltura);

        ingPeso = new JTextField();
        ingPeso.setBounds(135, 265, 150, 30);
        ingPeso.setText("5");
        pContenido.add(ingPeso);

        //---------------------------
        MosDistancia = new JTextField();
        MosDistancia.setBounds(60, 85, 200, 30);
        MosDistancia.setEditable(false);
        MosDistancia.setText("0");
        pVisualizar.add(MosDistancia);

        MosGravedad = new JTextField();
        MosGravedad.setBounds(285, 85, 200, 30);
        MosGravedad.setEditable(false);
        MosGravedad.setText("0");
        pVisualizar.add(MosGravedad);

        MosTiempo = new JTextField();
        MosTiempo.setBounds(510, 85, 200, 30);
        MosTiempo.setEditable(false);
        MosTiempo.setText("0");
        pVisualizar.add(MosTiempo);

        //-------------------------------------- JButtom
        bEjecutar = new JButton("Ejecutar");
        bEjecutar.setBounds(100, 410, 160, 50);
        bEjecutar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                eventoEjecutar();
            }
        });
        pContenido.add(bEjecutar);

    }

    //------------------------------------------ Eventos
    public void eventoEjecutar() {
        ganaste.setText("");
        int xfinal = 0;
        boolean error = true;
        try {
            ImageIcon logo = new ImageIcon(getClass().getResource("Imagenes/Fondofisica.jpg"));
            ImageIcon imgEscalada1 = new ImageIcon(logo.getImage().getScaledInstance(750, 480, Image.SCALE_DEFAULT));
            getGraphics().drawImage(imgEscalada1.getImage(), 30, 50, this);
        } catch (Exception e) {
            crearGUI();
        }
        try {

            Double.valueOf(ingAltura.getText());
            Double.valueOf(ingDistancia.getText());
            Double.valueOf(ingFuerza.getText());
            Double.valueOf(ingPeso.getText());

            String gra = (String) ingGravedad.getSelectedItem();
            switch (gra) {
                case "Tierra":
                    gravedad = 9.8;
                    break;
                case "Marte":
                    gravedad = 3.721;
                    ImageIcon logo2 = new ImageIcon(getClass().getResource("Imagenes/marte.jpeg"));
                    ImageIcon imgEscalada2 = new ImageIcon(logo2.getImage().getScaledInstance(750, 480, Image.SCALE_DEFAULT));
                    getGraphics().drawImage(imgEscalada2.getImage(), 30, 50, this);
                    break;
                case "Venus":
                    gravedad = 8.87;
                    ImageIcon logo3 = new ImageIcon(getClass().getResource("Imagenes/Venus.jpg"));
                    ImageIcon imgEscalada3 = new ImageIcon(logo3.getImage().getScaledInstance(750, 480, Image.SCALE_DEFAULT));
                    getGraphics().drawImage(imgEscalada3.getImage(), 30, 50, this);
                    break;
                case "Mercurio":
                    gravedad = 3.7;
                    ImageIcon logo4 = new ImageIcon(getClass().getResource("Imagenes/Mercurio.jpg"));
                    ImageIcon imgEscalada4 = new ImageIcon(logo4.getImage().getScaledInstance(750, 480, Image.SCALE_DEFAULT));
                    getGraphics().drawImage(imgEscalada4.getImage(), 30, 50, this);
                    break;
                case "Saturno":
                    gravedad = 10.44;
                    ImageIcon logo5 = new ImageIcon(getClass().getResource("Imagenes/Saturno.jpeg"));
                    ImageIcon imgEscalada5 = new ImageIcon(logo5.getImage().getScaledInstance(750, 480, Image.SCALE_DEFAULT));
                    getGraphics().drawImage(imgEscalada5.getImage(), 30, 50, this);
                    break;
                case "Neptuno":
                    gravedad = 11.15;
                    ImageIcon logo6 = new ImageIcon(getClass().getResource("Imagenes/Neptuno.jpg"));
                    ImageIcon imgEscalada6 = new ImageIcon(logo6.getImage().getScaledInstance(750, 480, Image.SCALE_DEFAULT));
                    getGraphics().drawImage(imgEscalada6.getImage(), 30, 50, this);
                    break;
                case "Urano":
                    gravedad = 8.87;
                    ImageIcon logo7 = new ImageIcon(getClass().getResource("Imagenes/Urano.png"));
                    ImageIcon imgEscalada7 = new ImageIcon(logo7.getImage().getScaledInstance(750, 480, Image.SCALE_DEFAULT));
                    getGraphics().drawImage(imgEscalada7.getImage(), 30, 50, this);
                    break;
                case "Jupiter":
                    gravedad = 24.79;
                    ImageIcon logo8 = new ImageIcon(getClass().getResource("Imagenes/Jupiter.png"));
                    ImageIcon imgEscalada8 = new ImageIcon(logo8.getImage().getScaledInstance(750, 480, Image.SCALE_DEFAULT));
                    getGraphics().drawImage(imgEscalada8.getImage(), 30, 50, this);
                    break;
                default:
            }

            altPersonaje = Integer.parseInt(ingAltura.getText());
            disObjeto = Integer.parseInt(ingDistancia.getText());
            fuerza = Integer.parseInt(ingFuerza.getText());
            peso = Integer.parseInt(ingPeso.getText());
            ImageIcon logo3 = new ImageIcon(getClass().getResource("Imagenes/Astronauta.png"));
            ImageIcon imgEscalada3 = new ImageIcon(logo3.getImage().getScaledInstance(100, 100, Image.SCALE_DEFAULT));
            getGraphics().drawImage(imgEscalada3.getImage(), 20, 500 - altPersonaje, this);

            ImageIcon logo4 = new ImageIcon(getClass().getResource("Imagenes/Asunto.png"));
            ImageIcon imgEscalada4 = new ImageIcon(logo4.getImage().getScaledInstance(40, 40, Image.SCALE_DEFAULT));
            getGraphics().drawImage(imgEscalada4.getImage(), disObjeto + 20, 480, this);

            ImageIcon logo5 = new ImageIcon(getClass().getResource("Imagenes/baloncesto.png"));
            ImageIcon imgEscalada5 = new ImageIcon(logo5.getImage().getScaledInstance(20, 20, Image.SCALE_DEFAULT));

            double yb;
            altura = Double.parseDouble(ingAltura.getText());
            for (double x = 0; x < 750; x += 8.5) {
                yb = (int) (Math.tan(0) * x - gravedad / (2 * fuerza * fuerza * Math.cos(0) * Math.cos(0)) * x * x);
                int x1 = (int) (x + 100);
                int y1 = (int) (550 - altPersonaje - yb - 20);
                getGraphics().drawImage(imgEscalada5.getImage(), x1, y1, this);
                Thread.sleep(120);
                if (y1 >= 450) {
                    break;
                }
                if (x1 >= 750) {
                    break;
                }
            }
            double y;

            for (double x = 0; x < 750; x += 0.01) {
                y = (Math.tan(0) * x - gravedad / (2 * fuerza * fuerza * Math.cos(0) * Math.cos(0)) * x * x);
                int x1 = (int) (x + 100);
                int y1 = (int) (550 - altPersonaje - y - 20);
                getGraphics().fillOval(x1, y1, 2, 2);
                if (y1 >= 520) {
                    xfinal = x1;
                    break;
                }
                if (x1 >= 750) {
                    break;
                }
            }
            System.out.println(xfinal);
            MosGravedad.setText(Double.toString(gravedad));
            DecimalFormat dm = new DecimalFormat("##.##");
            tiempo = (Math.sqrt(((2 * altura) / gravedad)));
            MosTiempo.setText(dm.format(tiempo));
            distancia = Integer.parseInt(ingFuerza.getText()) * tiempo;
            MosDistancia.setText(dm.format(distancia));
            
            if (distancia <= disObjeto + 50 && distancia >= disObjeto - 50) {
                JOptionPane.showMessageDialog(this, "GANASTE");
                ganaste.setText("GANASTE!!!");
            } else {
                JOptionPane.showMessageDialog(null, "FALLASTE");
                ganaste.setText("FALLASTE!!!");
                int respuesta = JOptionPane.showConfirmDialog(this, "¿Deseas Intentarlo de nuevo?", "confirmacion", JOptionPane.YES_NO_OPTION);

                if (respuesta == JOptionPane.YES_OPTION) {

                } else {
                    System.exit(0);
                }
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Debe llenar todos los campos con numeros");
        }
        if (cont == 2) {
            JOptionPane.showMessageDialog(this, "Se te acabaron los intentos");
            cont = 0;
            Fisica fi = new Fisica(mp);
            setVisible(false);
            dispose();

        }
        cont++;
    }

    public void limpiar() {

        ingAltura.setText("0");
        ingDistancia.setText("0");
        ingFuerza.setText("0");
        MosDistancia.setText("0");
        ingAltura.setText("0");
        MosGravedad.setText("0");
        MosTiempo.setText("0");

    }

    //------------------------------------------ MouseListener
    @Override
    public void mouseClicked(MouseEvent e) {
        int x = e.getX();
        int y = e.getY();

        System.out.println(x + "," + y);
    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

    @Override
    public void mouseDragged(MouseEvent e) {

    }

    @Override
    public void mouseMoved(MouseEvent e) {

    }

}
