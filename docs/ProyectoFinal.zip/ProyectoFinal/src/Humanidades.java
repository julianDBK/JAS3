
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Desktop;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;
import javax.swing.border.BevelBorder;

public class Humanidades extends JFrame {

    JButton jbVolver, jbAhorcado, video;
    JLabel jlTextoimg, titulo, mensaje, mensaje2;
    JTextArea contenido;
    JScrollPane js;
    MenuPrincipal mp;

    ArrayList<Estudiante> guardar = new ArrayList<>();
    
    FileReader leer;
    BufferedReader read;

    int pos, cont = 0;
    Integer [] notas;
    double[] num;

    public Humanidades(MenuPrincipal obj) {
        super("HUMANIDADES");
        mp = obj;
        setSize(800, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
        getContentPane().setBackground(Color.BLACK);
        Image icono = new ImageIcon(getClass().getResource("Imagenes/Logo.png")).getImage();
        setIconImage(icono);
        setLayout(null);
        crearGUI();
        setVisible(true);
    }

    public void crearGUI() {
        
        titulo = new JLabel("Humanidades II");
        titulo.setBounds(300, 10, 200, 80);
        titulo.setForeground(Color.WHITE);
        titulo.setFont(new Font("Times new Roman", Font.BOLD, 24));
        add(titulo);
        
        contenido = new JTextArea();
        contenido.setFont(new Font("Times new Roman", Font.BOLD, 20));
        contenido.setText("Desde el area de Humanidades podremos investigar las diferentes formas de reciclaje de los diferentes materiales "+ 
                " que podriamos encontrar tanto en la UCEVA como en lugares cotidianos, para asi plantear una posible solucion que combata la problematica " + 
                "de contaminacion ambiental por desechos y no solo esto si no que tambien podremos sensibilizar sobre el uso de energias con los que contamos dentro de la Universidad"
                + "");
        //Esto de la mano de las diversas carreras y areas de la universidad, pueden dar diversos proyectos enfocados a diversas problematicas
        //necesarias para combatir la contaminacion, para esto dejaremos una serie de problematicas planteadas
        contenido.setWrapStyleWord(true);
        contenido.setBackground(Color.BLACK);
        contenido.setForeground(Color.white);
        contenido.setLineWrap(true);
        contenido.setEditable(false);
        
        js = new JScrollPane(contenido);
        js.setBounds(40, 100, 300, 300);
        
        add(js);
        
        ImageIcon yt = new ImageIcon(getClass().getClassLoader().getResource("Imagenes/youtube.png")); 
        ImageIcon ytS = new ImageIcon(yt.getImage().getScaledInstance(120, 100, Image.SCALE_DEFAULT));
        video = new JButton(ytS);
        video.setBounds(550, 320, 120, 100);
        video.setOpaque(false);
        video.setToolTipText("Video JAS");
        video.setCursor(new Cursor(Cursor.HAND_CURSOR));
        video.setBackground(Color.white);
        video.setBorder(null);
        video.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                eventoVideo();
            }
        });
        add(video);
        
        
        mensaje = new JLabel("Video JAS");
        mensaje.setBounds(430, 350, 200, 50);
        mensaje.setForeground(Color.white);
        mensaje.setFont(new Font("Times new Roman", Font.BOLD, 24));
        add(mensaje);
        
        mensaje2 = new JLabel("Eres una persona con la capacidad de cuidar el medio ambiente");
        mensaje2.setBounds(70, 430, 650, 50);
        mensaje2.setForeground(Color.white);
        mensaje2.setFont(new Font("Times new Roman", Font.BOLD, 24));
        add(mensaje2);
        
        jbVolver = new JButton("Volver");
        jbVolver.setBounds(604, 505, 150, 40);
        jbVolver.setToolTipText("Click Aqui");
        jbVolver.setCursor(new Cursor(Cursor.HAND_CURSOR));
        jbVolver.setOpaque(false);
        jbVolver.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
        jbVolver.setBorderPainted(true);
        jbVolver.setBackground(Color.WHITE);
        jbVolver.setFocusPainted(false);
        jbVolver.setForeground(Color.WHITE);
        jbVolver.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                evento_jbVolver();
            }
        });
        add(jbVolver);

        jbAhorcado = new JButton("Ahorcado");
        jbAhorcado.setBounds(30, 505, 150, 40);
        jbAhorcado.setToolTipText("Realizar cuestionario");
        jbAhorcado.setCursor(new Cursor(Cursor.HAND_CURSOR));
        jbAhorcado.setOpaque(false);
        jbAhorcado.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
        jbAhorcado.setBorderPainted(true);
        jbAhorcado.setBackground(Color.WHITE);
        jbAhorcado.setFocusPainted(false);
        jbAhorcado.setForeground(Color.WHITE);
        jbAhorcado.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                evento_jbAhorcado();
            }
        });
        add(jbAhorcado);

        ImageIcon logo = new ImageIcon(getClass().getResource("Imagenes/Huma.png"));
        ImageIcon imgEscalada1 = new ImageIcon(logo.getImage().getScaledInstance(300, 200, Image.SCALE_DEFAULT));
        jlTextoimg = new JLabel(imgEscalada1);
        jlTextoimg.setBounds(400, 100, 300, 200);
        add(jlTextoimg);

    }

    public void eventoVideo(){
        gotoUrl("https://youtu.be/LORy643qwX8");
    }

    public void gotoUrl(String url){
        if (Desktop.isDesktopSupported()) {
            Desktop desktop = Desktop.getDesktop();

            if (desktop.isSupported(Desktop.Action.BROWSE)) {
                try {
                    URI uri = new URI(url);
                    desktop.browse(uri);
                } catch (URISyntaxException | IOException ex) {
                    JOptionPane.showMessageDialog(this, "Error al abrir la pagina " + url, "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }
    
    public void evento_jbAhorcado() {
        int respuesta = JOptionPane.showConfirmDialog(this, "¿Desea empezar a jugar?", "confirmacion", JOptionPane.YES_NO_OPTION);

        if (respuesta == JOptionPane.YES_OPTION) {
            //cuestion cu = new cuestion(this);
            Ahorcado eje = new Ahorcado();
            eje.Ejecutar();
            setVisible(false);
        }

    }

    public void evento_jbVolver() {
        setVisible(false);
        dispose();
        mp.setVisible(true);

    }
}
