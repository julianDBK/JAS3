
public class GenerarPreguntas {

    String pregunta, respuesta, resp_1, resp_2, resp_3;
    int pos, aux2, aux3;

    public GenerarPreguntas() {
        pregunta = respuesta = resp_1 = resp_2 = resp_3 = "-";
        pos = aux2 = aux3 = 0;
    }

    public void generar() {//------------------------------------------------------
        pos = (int) (Math.random() * 30);
        setPregunta();
        setAuxiliares();
        setRespuestas();

    }

    //-------------------------------------------------------------------------------
    public void setRespuestas() {
        setResp_1();
        setResp_2();
        setResp_3();
    }

    //-------------------------------------------------------------------------------
    public void setAuxiliares() {
        boolean igual;
        do {
            igual = false;
            aux2 = (int) (Math.random() * 30);
            if (aux2 == pos) {
                igual = true;
            }
        } while (igual);

        do {
            igual = false;
            aux3 = (int) (Math.random() * 30);
            if (aux3 == pos || aux3 == aux2) {
                igual = true;
            }
        } while (igual);

    }

    //-------------------------------------------------------------------------------
    public String getPregunta() {
        return pregunta;
    }

    public void setPregunta() {
        switch (pos) {
            case 1:
                pregunta = "¿Cuantos son los objetivos de desarrollo sostenible de la ONU?";
                break;
            case 2:
                pregunta = "¿Cual es el objetivo de desarrollo #8?";
                break;
            case 3:
                pregunta = "¿Que funcion tiene el crecimiento economico inclusivo?";
                break;
            case 4:
                pregunta = "¿Como afecta el covid-19 al fondo monetario internacional?";
                break;
            case 5:
                pregunta = "¿Cual es una de las lineas de trabajo socioeconomico?";
                break;
            case 6:
                pregunta = "¿Como se interconectan las lineas de trabajo?";
                break;
            case 7:
                pregunta = "¿Cual es la primera linea de trabajo socioeconomico?";
                break;
            case 8:
                pregunta = "¿Cual es la segunda linea de trabajo socioeconomico?";
                break;
            case 9:
                pregunta = "¿Cual es la tercera linea de trabajo socioeconomico?";
                break;
            case 10:
                pregunta = "¿Cual es la cuarta linea de trabajo socioeconomico?";
                break;
            case 11:
                pregunta = "¿Cual es la quinta linea de trabajo socioeconomico?";
                break;
            case 12:
                pregunta = "¿Cual es uno de los datos mas destacables del tema?";
                break;
            case 13:
                pregunta = "¿Cual NO es una de las metas del objetivo 8?";
                break;
            case 14:
                pregunta = "Adaptar medidas inmediatas y eficaces para erradicar el trabajo forzoso ¿Es una de las metas del objetivo #8?";
                break;
            case 15:
                pregunta = "¿En donde se llevo a cabo la exposicion mundial del desarrollo?";
                break;
            case 16:
                pregunta = "Cada vez que utilizamos nuestro celular para acceder a servicios, ¿Que funcion realizamos?";
                break;
            case 17:
                pregunta = "En promedio, ¿Cuantas personas carecen de proteccion social?";
                break;
            case 18:
                pregunta = "¿Cual es el titulo completo del objetivo #8?";
                break;
            case 19:
                pregunta = "¿Quien es el encargado de la recuperacion de la crisis del covid-19 en la economia?";
                break;
            case 20:
                pregunta = "¿Cual deberia ser el incentivo respecto a la pandemia?";
                break;
            case 21:
                pregunta = "cual es una de las tendencias del mercado laboral ?";
                break;
            case 22:
                pregunta = "Que es la ONU?";
                break;
            case 23:
                pregunta = "Cuantos participantes hay en la ONU?";
                break;
            case 24:
                pregunta = "Cuantos puestos de trabajo se necesitan entre 2016 y 2030?";
                break;
            case 25:
                pregunta = "Cual es la tasa de participación de la mujer en la población Activa?";
                break;
            case 26:
                pregunta = "Cual fue la tasa mundial de desempleo en 2017?";
                break;
            case 27:
                pregunta = "Cuanto porcentaje de trabajadores tenia un empleo no regulado en 2016?";
                break;
            case 28:
                pregunta = "El fortalecer la capacidad de las instituciones financieras es una meta del objetico #8?";
                break;
            case 29:
                pregunta = "Que se piensa realizar de aquí al 2025?";
                break;
            case 30:
                pregunta = "A quienes se busca proteger en los derechos laborales?";
                break;
        }
    }

    //-------------------------------------------------------------------------------
    public String getRespuesta() {
        return respuesta;
    }

    public void setRespuesta(int num) {
        switch (num) {
            case 1:
                respuesta = "17.";
                break;
            case 2:
                respuesta = "Trabajo decente y crecimiento economico.";
                break;
            case 3:
                respuesta = "Impulsar al progreso, crear empleos decentes y mejorar los estandares de vida.";
                break;
            case 4:
                respuesta = "Con una recesion mundial tan mala o peor que la del 2009.";
                break;
            case 5:
                respuesta = "Promover la cohesion social e invertir en sistemas de respuesta y resiliencia impulsados por las comunidades.";
                break;
            case 6:
                respuesta = "Mediante un solido imperativo de sostenibilidad medioambiental y de igualdad de genero para una mejor reconstruccion.";
                break;
            case 7:
                respuesta = "Garantizar que los servicios de salud esenciales sigan estando disponibles y proteger los sistemas sanitarios.";
                break;
            case 8:
                respuesta = "Ayudar a las personas a lidiar con la adversidad mediante la proteccion social y servicios basicos.";
                break;
            case 9:
                respuesta = "Proteger empleos y apoyar a pequeñas y medianas empresas, y a los trabajadores del sector informal.";
            case 10:
                respuesta = "Orientar el aumento necesario de estimulos fiscales y financieros.";
                break;
            case 11:
                respuesta = "Promover la cohesion social e invertir en sistemas de respuesta y resiliencia impulsados por las comunidades.";
                break;
            case 12:
                respuesta = "En  2017, la tasa de mundial de desempleo se situaba en el 5,6%, frente al 6,4% del año 2000.";
                break;
            case 13:
                respuesta = "Desarrollar infraestructuras fiables, sostenibles, resilientes y de calidad.";
                break;
            case 14:
                respuesta = "Si.";
                break;
            case 15:
                respuesta = "Nueva York.";
                break;
            case 16:
                respuesta = "16";
                break;
            case 17:
                respuesta = "Más de 4.000 millones de personas.";
                break;
            case 18:
                respuesta = "Trabajo decente y crecimiento economico.";
                break;
            case 19:
                respuesta = "Secretario General de las Naciones Unidas.";
                break;
            case 20:
                respuesta = "Encauzar al mundo hacia un camino de desarrollo más sostenible.";
                break;
            case 21:
                respuesta = "Observatorio de la OIT sobre el mundo del trabajo.";
                break;
            case 22:
                respuesta = "Organización de la Naciones Unidas.";
                break;
            case 23:
                respuesta = "20769.";
                break;
            case 24:
                respuesta = "470 millones.";
                break;
            case 25:
                respuesta = "63%";
                break;
            case 26:
                respuesta = "5.6%";
                break;
            case 27:
                respuesta = "61%";
                break;
            case 28:
                respuesta = "Si.";
                break;
            case 29:
                respuesta = "Poner fin al trabajo infantil en todas sus formas.";
                break;
            case 30:
                respuesta = "A las mujeres migrantes.";
                break;
        }

    }

    //-------------------------------------------------------------------------------
    public String getResp_1() {
        return resp_1;
    }

    public void setResp_1() {
        setRespuesta(pos);
        resp_1 = respuesta;
    }

    //-------------------------------------------------------------------------------
    public String getResp_2() {
        return resp_2;
    }

    public void setResp_2() {
        setRespuesta(aux2);
        resp_2 = respuesta;
    }

    //-------------------------------------------------------------------------------
    public String getResp_3() {
        return resp_3;
    }

    public void setResp_3() {
        setRespuesta(aux3);
        resp_3 = respuesta;
    }

    //-------------------------------------------------------------------------------
    public int getPos() {
        return pos;
    }

    public void setPos(int pos) {
        this.pos = pos;
    }

    //-------------------------------------------------------------------------------
}
