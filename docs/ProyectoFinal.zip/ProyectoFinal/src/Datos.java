


public class Datos {
    
    String nombre, codigo;
    
    public Datos(){
        nombre = codigo = "";
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    //-----------------------------------------------
    
    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }
    
    //-------------------------------------------------

    
    
    
    
}
