
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.text.DecimalFormat;
import java.util.ArrayList;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;
import javax.swing.border.BevelBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;

public class CalcVectores extends JFrame implements MouseListener {

    JPanel panel, panel2, panel3;
    JTextField IngX, IngY, IngM, MosA, IngE, MosE, Msum, Mesc, Mvec, MosM, MosDx, MosDy;
    JLabel posx, posy, magnitud, angulo, Escalar, rE, Suma, Esc, Vec, mixto, descX, descY;
    JButton operar, seleccionar, volver, limpiar;
    JRadioButton suma, productoporescalar, productoescalar, productovectorial, productomixto, descomposicion;

    int X = 0, Y = 0;

    Color jas = new Color(231, 75, 50);
    ArrayList<Posiciones> save = new ArrayList<>();
    ArrayList<Integer> pX = new ArrayList<Integer>();
    ArrayList<Integer> pY = new ArrayList<Integer>();
    AlgebraLineal al;

    int equis, ye, cont = 0, sumax = 0, sumay = 0;

    public CalcVectores(AlgebraLineal ob) {
        super("Calculadora de Vectores");
        addMouseListener(this);
        al = ob;
        setSize(1000, 750);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
        Image icono = new ImageIcon(getClass().getResource("Imagenes/Logo.png")).getImage();
        setIconImage(icono);
        setLayout(null);
        setVisible(true);
        imagen();

    }

    public void imagen() {
        panel = new JPanel();
        panel.setBounds(0, 0, 1000, 750);
        panel.setBorder(new LineBorder(Color.WHITE));
        panel.setLayout(null);
        crearGUI();

        add(panel);
    }

    //------------------------------------------------------------------------------------
    public void paint(Graphics g) {
        super.paint(g);
        g.setColor(Color.BLACK);
        g.drawRect(300, 50, 665, 550);
        g.fillRect(632, 50, 5, 550);
        g.fillRect(300, 325, 665, 5);

        add(g);
    }

    //------------------------------------------------------------------------------------ PANELES
    public void crearGUI() {

        panel2 = new JPanel();
        panel2.setBounds(20, 590, 940, 100);
        panel2.setLayout(null);
        panel2.setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED));
        panel2.setBorder(new LineBorder(Color.BLACK));
        panel2.setOpaque(false);
        panel.add(panel2);

        panel3 = new JPanel();
        panel3.setBounds(20, 20, 255, 550);
        panel3.setLayout(null);
        panel3.setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED));
        panel3.setBorder(new LineBorder(Color.BLACK));

        panel.add(panel3);

        //------------------------------------------------------------------------------------ BOTONES
        operar = new JButton("Calcular");
        operar.setBounds(770, 35, 140, 40);
        operar.setCursor(new Cursor(Cursor.HAND_CURSOR));
        operar.setForeground(Color.BLACK);
        operar.setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED));
        operar.setBackground(Color.BLACK);
        operar.setOpaque(false);
        operar.setBorder(new LineBorder(Color.BLACK));
        operar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                eventoGraficar();
            }
        });
        panel2.add(operar);

        seleccionar = new JButton("Seleccione una opcion:");
        seleccionar.setBounds(30, 220, 190, 40);
        seleccionar.setCursor(new Cursor(Cursor.HAND_CURSOR));
        seleccionar.setBackground(Color.BLACK);
        seleccionar.setForeground(Color.WHITE);
        seleccionar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                eventoSeleccionar();
            }
        });
        panel3.add(seleccionar);

        volver = new JButton("Volver");
        volver.setBounds(5, 500, 100, 40);
        volver.setOpaque(false);
        volver.setCursor(new Cursor(Cursor.HAND_CURSOR));
        volver.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
        volver.setBackground(Color.WHITE);
        volver.setForeground(Color.BLACK);
        volver.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                evento_jbVolver();
            }
        });
        panel3.add(volver);

        limpiar = new JButton("Limpiar");
        limpiar.setBounds(140, 500, 100, 40);
        limpiar.setOpaque(false);
        limpiar.setCursor(new Cursor(Cursor.HAND_CURSOR));
        limpiar.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
        limpiar.setBackground(Color.WHITE);
        limpiar.setForeground(Color.BLACK);
        limpiar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                eventoLimpiar();
            }
        });
        panel3.add(limpiar);

        //------------------------------------------------------------------------------------ Lables
        posx = new JLabel("Componente X:");
        posx.setBounds(30, 25, 120, 30);
        posx.setForeground(Color.BLACK);
        posx.setFont(new Font("Arial", Font.BOLD, 14) {
        });
        panel2.add(posx);

        posy = new JLabel("Componente Y:");
        posy.setBounds(240, 25, 120, 30);
        posy.setForeground(Color.BLACK);
        posy.setFont(new Font("Arial", Font.BOLD, 14) {
        });
        panel2.add(posy);

        magnitud = new JLabel("Magnitud:");
        magnitud.setBounds(30, 60, 120, 30);
        magnitud.setForeground(Color.BLACK);
        magnitud.setFont(new Font("Arial", Font.BOLD, 14));
        panel2.add(magnitud);

        angulo = new JLabel("Angulo");
        angulo.setBounds(230, 60, 120, 30);
        angulo.setForeground(Color.BLACK);
        angulo.setFont(new Font("Arial", Font.BOLD, 14));
        panel2.add(angulo);

        Escalar = new JLabel("Escalar");
        Escalar.setBounds(450, 25, 120, 30);
        Escalar.setForeground(Color.BLACK);
        Escalar.setFont(new Font("Arial", Font.BOLD, 14));
        panel2.add(Escalar);

        rE = new JLabel("Producto Escalar");
        rE.setBounds(10, 270, 120, 30);
        rE.setForeground(Color.BLACK);
        rE.setFont(new Font("Arial", Font.BOLD, 14));
        panel3.add(rE);

        Suma = new JLabel("Suma Vectorial");
        Suma.setBounds(10, 315, 120, 30);
        Suma.setForeground(Color.BLACK);
        Suma.setFont(new Font("Arial", Font.BOLD, 14));
        panel3.add(Suma);

        Esc = new JLabel("Producto X Escalar");
        Esc.setBounds(10, 360, 120, 30);
        Esc.setForeground(Color.BLACK);
        Esc.setFont(new Font("Arial", Font.BOLD, 14));
        panel3.add(Esc);

        Vec = new JLabel("Producto Vectorial");
        Vec.setBounds(10, 405, 120, 30);
        Vec.setForeground(Color.BLACK);
        Vec.setFont(new Font("Arial", Font.BOLD, 14));
        panel3.add(Vec);

        mixto = new JLabel("Producto Mixto");
        mixto.setBounds(10, 450, 120, 30);
        mixto.setForeground(Color.BLACK);
        mixto.setFont(new Font("Arial", Font.BOLD, 14));
        panel3.add(mixto);

        descX = new JLabel("Desc X");
        descX.setBounds(430, 60, 120, 30);
        descX.setForeground(Color.BLACK);
        descX.setFont(new Font("Arial", Font.BOLD, 14));
        panel2.add(descX);

        descY = new JLabel("Desc Y");
        descY.setBounds(600, 60, 120, 30);
        descY.setForeground(Color.BLACK);
        descY.setFont(new Font("Arial", Font.BOLD, 14));
        panel2.add(descY);

        //------------------------------------------------------------------------------------ TextField
        IngX = new JTextField();
        IngX.setBounds(145, 30, 80, 20);
        IngX.setText("0");
        panel2.add(IngX);

        IngM = new JTextField();
        IngM.setBounds(110, 65, 100, 20);
        IngM.setEditable(false);
        panel2.add(IngM);

        IngY = new JTextField();
        IngY.setBounds(355, 30, 80, 20);
        IngY.setText("0");
        panel2.add(IngY);

        MosA = new JTextField();
        MosA.setBounds(290, 65, 120, 20);
        MosA.setEditable(false);
        panel2.add(MosA);

        IngE = new JTextField();
        IngE.setBounds(510, 30, 120, 20);
        IngE.setText("0");
        panel2.add(IngE);

        Msum = new JTextField();
        Msum.setBounds(140, 320, 90, 20);
        Msum.setText("0");
        Msum.setEditable(false);
        panel3.add(Msum);

        MosE = new JTextField();
        MosE.setBounds(140, 275, 90, 20);
        MosE.setText("0");
        MosE.setEditable(false);
        panel3.add(MosE);

        Mesc = new JTextField();
        Mesc.setBounds(140, 365, 90, 20);
        Mesc.setText("0");
        Mesc.setEditable(false);
        panel3.add(Mesc);

        Mvec = new JTextField();
        Mvec.setBounds(140, 410, 90, 20);
        Mvec.setText("0");
        Mvec.setEditable(false);
        panel3.add(Mvec);

        MosM = new JTextField();
        MosM.setBounds(140, 455, 90, 20);
        MosM.setText("0");
        MosM.setEditable(false);
        panel3.add(MosM);

        MosDx = new JTextField();
        MosDx.setBounds(490, 65, 90, 20);
        MosDx.setEditable(false);
        panel2.add(MosDx);

        MosDy = new JTextField();
        MosDy.setBounds(660, 65, 90, 20);
        MosDy.setEditable(false);
        panel2.add(MosDy);

        //------------------------------------------------------------------------------------ RadioButtom
        Font fn = new Font("Tahoma", Font.PLAIN, 12);

        suma = new JRadioButton("     Suma");
        suma.setFont(fn);
        suma.setCursor(new Cursor(Cursor.HAND_CURSOR));
        suma.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
        suma.setBorder(new LineBorder(Color.BLACK));
        suma.setBorderPainted(true);
        suma.setFocusPainted(false);
        suma.setForeground(Color.BLACK);
        suma.setBounds(5, 20, 100, 30);
        panel3.add(suma);

        productovectorial = new JRadioButton("  Producto Vectorial");
        productovectorial.setFont(fn);
        productovectorial.setCursor(new Cursor(Cursor.HAND_CURSOR));
        productovectorial.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
        productovectorial.setBorder(new LineBorder(Color.BLACK));
        productovectorial.setBorderPainted(true);
        productovectorial.setOpaque(false);
        productovectorial.setFocusPainted(false);
        productovectorial.setForeground(Color.BLACK);
        productovectorial.setBounds(115, 20, 130, 30);
        panel3.add(productovectorial);

        productoporescalar = new JRadioButton("  Producto por un Escalar");
        productoporescalar.setFont(fn);
        productoporescalar.setCursor(new Cursor(Cursor.HAND_CURSOR));
        productoporescalar.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
        productoporescalar.setBorder(new LineBorder(Color.BLACK));
        productoporescalar.setBorderPainted(true);
        productoporescalar.setOpaque(false);
        productoporescalar.setFocusPainted(false);
        productoporescalar.setForeground(Color.BLACK);
        productoporescalar.setBounds(5, 70, 175, 30);
        panel3.add(productoporescalar);

        productoescalar = new JRadioButton(" Producto Escalar");
        productoescalar.setFont(fn);
        productoescalar.setCursor(new Cursor(Cursor.HAND_CURSOR));
        productoescalar.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
        productoescalar.setBorder(new LineBorder(Color.BLACK));
        productoescalar.setBorderPainted(true);
        productoescalar.setOpaque(false);
        productoescalar.setFocusPainted(false);
        productoescalar.setForeground(Color.BLACK);
        productoescalar.setBounds(5, 120, 120, 30);
        panel3.add(productoescalar);

        productomixto = new JRadioButton(" Producto Mixto");
        productomixto.setFont(fn);
        productomixto.setCursor(new Cursor(Cursor.HAND_CURSOR));
        productomixto.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
        productomixto.setBorder(new LineBorder(Color.BLACK));
        productomixto.setBorderPainted(true);
        productomixto.setOpaque(false);
        productomixto.setFocusPainted(false);
        productomixto.setForeground(Color.BLACK);
        productomixto.setBounds(135, 120, 110, 30);
        panel3.add(productomixto);

        descomposicion = new JRadioButton(" Descomposicion de un vector");
        descomposicion.setFont(fn);
        descomposicion.setCursor(new Cursor(Cursor.HAND_CURSOR));
        descomposicion.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
        descomposicion.setBorder(new LineBorder(Color.BLACK));
        descomposicion.setBorderPainted(true);
        descomposicion.setOpaque(false);
        descomposicion.setFocusPainted(false);
        descomposicion.setForeground(Color.BLACK);
        descomposicion.setBounds(5, 170, 190, 30);
        panel3.add(descomposicion);

        ButtonGroup bg = new ButtonGroup();
        bg.add(suma);
        bg.add(productovectorial);
        bg.add(productoescalar);
        bg.add(productoporescalar);
        bg.add(productomixto);
        bg.add(descomposicion);

        //------------------------------------------------------------------------------------ FIN GUI
    }

    //------------------------------------------------------------------------------------ Eventos
    public void eventoLimpiar() {
        save.clear();
        cont = 0;
        sumax = 0;

        sumay = 0;
        IngX.setText("0");
        IngY.setText("0");
        IngM.setText("0");
        MosA.setText("0");
        MosE.setText("0");
        IngE.setText("0");
        Msum.setText("0");
        Mesc.setText("0");
        Mvec.setText("0");
        pX.removeAll(pX);
        pY.removeAll(pY);
        setVisible(false);
        setVisible(true);
        limpiarRadio();
    }

    public void evento_jbVolver() {

        setVisible(false);
        dispose();
        al.setVisible(true);
    }

    public void eventoSeleccionar() {
        if (suma.isSelected()) {
            boolean error = false;
            try {
                if (Msum.getText().isEmpty() || pX.size() == 0) {
                    error = true;
                    JOptionPane.showMessageDialog(this, "Grafica al menos un vector antes");
                }

                if (!error) {
                    Msum.setText(String.valueOf((sumax) + " X    " + sumay + " Y"));
                    int k = 5;
                    int x1, y1;
                    x1 = 635 + sumax;
                    y1 = ((sumay - 328) * -1);
                    double alfa = Math.atan2(y1 - 328, x1 - 635);
                    int flecha1 = (int) (x1 - k * Math.cos(alfa + 1));
                    int flecha2 = (int) (y1 - k * Math.sin(alfa + 1));
                    getGraphics().drawLine(flecha1, flecha2, x1, y1);
                    flecha1 = (int) (x1 - k * Math.cos(alfa - 1));
                    flecha2 = (int) (y1 - k * Math.sin(alfa - 1));
                    getGraphics().drawLine(flecha1, flecha2, x1, y1);
                    getGraphics().drawLine(635, 328, x1, y1);
                    getGraphics().drawLine(635, 328, (sumax + 635), ((sumay - 328) * -1));
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Error ");
            }
        }
        if (productoporescalar.isSelected()) {
            eventoPorEscalar();
        }
        if (productoescalar.isSelected()) {
            eventoEscalar();
        }
        if (productovectorial.isSelected()) {
            eventoVectorial();
        }
        if (productomixto.isSelected()) {
            eventoMixto();
        }
        if (descomposicion.isSelected()) {
            MosA.setEditable(true);
            JOptionPane.showMessageDialog(null, "Digite el angulo para descomponer el vector");
        }
        limpiarRadio();
    }

    public void eventoDescomposicion() {
        int A;
        double x, y, dx, dy;
        boolean error = false;
        try {
            if (pX.size() == 0) {
                JOptionPane.showMessageDialog(this, "Grafica al menos un vector ");
                error = true;
            }
            if (!error) {
                calcMagnitud();
                x = X - 635;
                y = 328 - Y;
                A = Integer.parseInt(MosA.getText());

                dx = Double.parseDouble(IngM.getText()) * (Math.cos(Math.toRadians(A)));
                dy = Double.parseDouble(IngM.getText()) * (Math.sin(Math.toRadians(A)));

                dx = Math.round(dx);
                dy = Math.round(dy);

                MosDx.setText(String.valueOf(dx));
                MosDy.setText(String.valueOf(dy));
            }
        } catch (Exception e) {
        }
    }

    public void eventoMixto() {
        int x1, x2, x3, y1, y2, y3, px, py, px2, py2, pm;
        boolean error = false;
        try {
            if (pX.size() < 3) {
                error = true;
                JOptionPane.showMessageDialog(this, "Grafique al menos 3 vectores");
            }

            if (!error) {
                x3 = X - 635;
                y3 = 328 - Y;

                Mesc.setText(String.valueOf(x3) + " i   ,  " + String.valueOf(y3) + " j  ");

                Posiciones tmp = save.get(cont - 2);
                Posiciones tmp2 = save.get(cont - 3);

                x2 = tmp.getX() - 635;
                y2 = 328 - tmp.getY();

                x1 = tmp2.getX() - 635;
                y1 = 328 - tmp2.getY();

                JOptionPane.showConfirmDialog(null, "Primero = " + x1 + " , " + y1
                        + "\nSegundo = " + x2 + " , " + y2
                        + "\nTercero = " + x3 + " , " + y3);

                px = x1 * y2;
                py = y1 * x2;
                JOptionPane.showMessageDialog(null, "Py = " + py + "  " + y1 + "  -  " + x2);

                Mvec.setText(String.valueOf(px) + " i   ,  " + String.valueOf(py) + " j  ");

                px2 = px * x3;
                py2 = py * -y3;
                pm = px2 + py2;

                MosM.setText(String.valueOf(pm));
            }

        } catch (Exception e) {
        }

    }

    public void eventoVectorial() {
        int x1, x2, y1, y2, px, py;
        boolean error = false;
        try {
            if (pX.size() < 2) {
                error = true;
                JOptionPane.showMessageDialog(this, "Grafique al menos 2 vectores");
            }

            if (!error) {
                x2 = X - 635;
                y2 = 328 - Y;
                //JOptionPane.showMessageDialog(null, cont + " , " + (cont-2));
                Posiciones tmp = save.get(cont - 2);
                x1 = tmp.getX() - 635;
                y1 = 328 - tmp.getY();
                JOptionPane.showConfirmDialog(null, "Anteriores = " + (tmp.getX() - 635) + " , " + (328 - tmp.getY())
                        + "\nNuevos = " + x2 + " , " + y2);

                px = x1 - y2;
                py = y1 - x2;

                int k = 5;
                int x3, y3;

                x3 = 635 + px;
                y3 = (328 - py);
                double alfa = Math.atan2(y1 - 328, x1 - 635);
                int flecha1 = (int) (x3 - k * Math.cos(alfa + 1));
                int flecha2 = (int) (y3 - k * Math.sin(alfa + 1));
                getGraphics().drawLine(flecha1, flecha2, x3, y3);
                flecha1 = (int) (x3 - k * Math.cos(alfa - 1));
                flecha2 = (int) (y3 - k * Math.sin(alfa - 1));
                getGraphics().drawLine(flecha1, flecha2, x3, y3);
                getGraphics().drawLine(635, 328, x3, y3);
                Mvec.setText(String.valueOf(px) + " i    " + String.valueOf(py) + " j  ");
            }
        } catch (Exception e) {
        }

    }

    public void eventoEscalar() {

        int x1, x2, y1, y2, px, py;
        boolean error = false;
        try {
            if (pX.size() < 2) {
                JOptionPane.showMessageDialog(this, "Grafica al menos dos vectores ");
                error = true;
            }
            if (!error) {

                x2 = X - 635;
                y2 = 328 - Y;
                Posiciones tmp = save.get(cont - 2);
                x1 = tmp.getX() - 635;
                y1 = 328 - tmp.getY();
                JOptionPane.showConfirmDialog(null, "Anteriores = " + (tmp.getX() - 635) + " , " + (328 - tmp.getY())
                        + "\nNuevos = " + x2 + " , " + y2);

                px = x1 * x2;
                py = y1 * y2;
                DecimalFormat dc = new DecimalFormat("#");

                Mesc.setText(dc.format(px + py));
            }
        } catch (Exception e) {

        }
    }

    public void eventoPorEscalar() {
        boolean error = false;
        try {
            if (pX.size() == 0) {
                JOptionPane.showMessageDialog(this, "Grafica al menos un vector ");
                error = true;
            }
            if (!error) {
              int e = Integer.parseInt(IngE.getText());
            int escX, escY, x1, y1, k = 5;
            escX = e * (X - 635);

            escY = e * -(Y - 328);
            x1 = 635 + escX;
            y1 = ((escY - 328) * -1);
            double alfa = Math.atan2(y1 - 328, x1 - 635);
            int flecha1 = (int) (x1 - k * Math.cos(alfa + 1));
            int flecha2 = (int) (y1 - k * Math.sin(alfa + 1));
            getGraphics().drawLine(flecha1, flecha2, x1, y1);
            flecha1 = (int) (x1 - k * Math.cos(alfa - 1));
            flecha2 = (int) (y1 - k * Math.sin(alfa - 1));
            getGraphics().drawLine(flecha1, flecha2, x1, y1);
            getGraphics().drawLine(635, 328, x1, y1);
            getGraphics().drawLine(635, 328, x1, y1);
            //getGraphics().drawLine(635, 328, (escX + 635), ((escY - 328) * -1));

            MosE.setText(String.valueOf(escX) + " i    " + String.valueOf(escY) + " j  ");  
            }
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "llene la casilla escalar con numeros");
        }
    }

    public void eventoGraficar() {
        if (X > 300 && Y > 50 && X < 965 && Y < 600) {
            Posiciones tmp = new Posiciones();
            if (!"0".equals(IngX.getText()) && !"0".equals(IngY.getText())) {
                int pos = Integer.parseInt(IngX.getText());
                X = pos + 635;
                int pos2 = Integer.parseInt(IngY.getText());
                Y = 328 - pos2;
            }
            if (descomposicion.isSelected()) {
                eventoDescomposicion();
            } else {
                calcAngulo();
            }
            tmp.setX(X);
            tmp.setY(Y);
            cont++;
            calcMagnitud();

            save.add(tmp);

            getGraphics().drawLine(635, 328, X, Y);

        }
    }

    //------------------------------------------------------------------------------------ Metodos Aparte
    public void limpiarRadio() {
        suma.setSelected(false);
        productoporescalar.setSelected(false);
        productoescalar.setSelected(false);
        productovectorial.setSelected(false);
    }

    public void calcMagnitud() {
        double r;
        double c1, c2;

        c1 = (double) Math.pow(X - 635, 2);
        c2 = (double) Math.pow(Y - 328, 2);
        r = Math.sqrt(c1 + c2);
        r = Math.round(r);
        IngM.setText(String.valueOf(r));
    }

    public void calcAngulo() {
        double ang, x;
        ang = Math.atan(Y / X);
        x = Math.toDegrees(ang);
        //ang= Math.round(ang);
        MosA.setText(String.valueOf(ang));
    }

    private void add(Graphics g) {

    }

    //------------------------------------------------------------------------------------ MouseListener
    @Override
    public void mouseClicked(MouseEvent e) {
        pX.add(e.getX() - 635);
        pY.add((e.getY() - 328) * -1);
        sumax = pX.stream().mapToInt(Integer::valueOf).sum();
        sumay = pY.stream().mapToInt(Integer::valueOf).sum();
        X = e.getX();
        Y = e.getY();
        IngX.setText(String.valueOf(X - 635));
        IngY.setText(String.valueOf((Y - 328) * -1));

    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

}
