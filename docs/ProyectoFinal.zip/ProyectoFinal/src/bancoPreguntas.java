

import javax.swing.JOptionPane;

public class bancoPreguntas {

    int[] preguntas = new int[10];
    int[][] respuestasIncorrectas = new int[10][3];

    int i;

    public int[] generarPregunta() {

        int numeroPregunta = 0, maxPreguntas = 0;

        boolean esDiferente = false;
        numeroPregunta = (int) (Math.random() * 10 + 1);
        preguntas[i] = numeroPregunta;

        for (i = 0; i < 20; i++) {
            numeroPregunta = (int) (Math.random() * 20 + 1);
            esDiferente = true;

            for (int j = 0; j < preguntas.length; j++) {

                int pregunta = preguntas[j];

                if (pregunta == numeroPregunta) {
                    esDiferente = false;
                }
            }

            if (esDiferente && maxPreguntas < 10) {
                preguntas[i] = numeroPregunta;
                maxPreguntas++;
            } else {
                if (!esDiferente) {
                    i--;
                }

            }

        }

        //mostrarDatos();
        return preguntas;
    }

    public int[] respuestas(int pos) {
        int[] resp = new int[3];

        resp[0] = getPregunta(pos);
        
        int aux = 0;

        do {
            aux = (int) (Math.random() * 20 + 1);
            

        } while (getPregunta(aux) == resp[0]);

        resp[1] = getPregunta(aux);

        do {
            aux = (int) (Math.random() * 20 + 1);
            

        } while (getPregunta(aux) == resp[1] || getPregunta(aux) == resp[0]);

        resp[2] = getPregunta(aux);

        return resp;
    }

    public int getPregunta(int posicion) {
        int pos = 0;
        switch (posicion) {
            case 1:
                pos = 0;
                break;
            case 2:
                pos = 1;
                break;
            case 3:
                pos = 2;
                break;
            case 4:
                pos = 3;
                break;
            case 5:
                pos = 4;
                break;
            case 6:
                pos = 5;
                break;
            case 7:
                pos = 6;
                break;
            case 8:
                pos = 7;
                break;
            case 9:
                pos = 8;
                break;
            case 10:
                pos = 9;
                break;
        }
        return preguntas[pos];
    }

    public void mostrarDatos() {
        for (int j = 0; j < preguntas.length; j++) {
            int pregunta = preguntas[j];
            System.out.println(j + ".  " + pregunta);
        }
    }

}
